<?
session_start();
include "base.php";
if (isset($_SESSION['nivel'])) 
{
 	$logado = $_SESSION['nivel'];
  	if ($logado == '2')
	{
	$idusuario = $_SESSION['id'];
	//selecionando dados do usuario
	$result = mysql_query("SELECT postograd, guerra FROM usuarios WHERE id LIKE '%".$idusuario."%';",$conexaolivro);
	$Quantos = mysql_num_rows($result);
	if($Quantos > 0)
	{
	//iniciando vari�veis

	$postograd = mysql_result($result,0,postograd);
	$guerra = mysql_result($result,0,guerra);
	
	// Fun��o para transformar strings em Mai�scula ou Min�scula com acentos
			// $palavra = a string propriamente dita
			// $tp = tipo da convers�o: 1 para mai�sculas e 0 para min�sculas
			function convertem($term, $tp) {
				if ($tp == "1") $palavra = strtr(strtoupper($term),"������������������������������","������������������������������");
				elseif ($tp == "0") $palavra = strtr(strtolower($term),"������������������������������","������������������������������");
				return $palavra;
			} 
	
echo '

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Livro</title>';

?>
<script LANGUAGE="JavaScript">
    totalssv =0;
	function deleteRowSv(i){
	
    document.getElementById('tabelasv').deleteRow(i)
	
    }
    function adicionasv(){
    totalssv++
	
	//aqui a input hidden de id="totalssv" que est� no fim do form recebe o valor da variavel totalssv

	//cria um objeto de refer�ncia � tag input hidden
	var objetoDados = document.getElementById("totalssv");
	//altera o atributo value desta tag
	objetoDados.value = totalssv;
	
        tbl = document.getElementById("tabelasv")

        var novaLinha = tbl.insertRow(-1);
        var novaCelula;

        if(totalssv%2==0) cl = "#b0b0b0";
        else cl = "#dadada";

        novaCelula = novaLinha.insertCell(0);

        novaCelula.style.backgroundColor = cl

        novaCelula.innerHTML = "<select name='funcaosv["+totalssv+"]'><option value=''>Selecione</option><option value='orc'>ORC</option><option value='ofdia'>Of Dia</option><option value='adjofdia'>Adj Of Dia</option><option value='cmtgda'>Cmt Gda</option><option value='cbgdafte'>Cb Gda Fte</option><option value='cbgdafun'>Cb Gda Fun</option><option value='motdia'>Mot Dia</option><option value='sgtdran'>Sgt D Ran</option><option value='clarin'>Clarin</option><option value='comsoc'>Com Soc</option><option value='medsbv'>Med SBV</option><option value='dentsbv'>Dent SBV</option><option value='atddia'>Atd Dia</option><option value='eltdia'>Elt Dia</option><option value='teldia'>Tel Dia</option><option value='permcanil'>Perm Canil</option><option value='revdia'>Rev Dia</option></select>";



        novaCelula = novaLinha.insertCell(1);
        novaCelula.align = "left";
        novaCelula.style.backgroundColor = cl;
        novaCelula.innerHTML = "<select name='postogradsv["+totalssv+"]'><option value=''>Selecione</option><option value='cap'>Cap</option><option value='1ten'>1� Ten</option><option value='2ten'>2� Ten</option><option value='asp'>Asp</option><option value='1sgt'>1� Sgt</option><option value='2sgt'>2� Sgt</option><option value='3sgt'>3� Sgt</option><option value='t1'>T1</option><option value='cb'>Cb</option><option value='sdnb'>Sd NB</option><option value='sdev'>Sd EV</option></select>";

		novaCelula = novaLinha.insertCell(2);
        novaCelula.align = "left";
        novaCelula.style.backgroundColor = cl;
        novaCelula.innerHTML = "<input type='text' name='nomesv["+totalssv+"]' size='30'>";
		
		novaCelula = novaLinha.insertCell(3);
        novaCelula.align = "left";
        novaCelula.style.backgroundColor = cl;
        novaCelula.innerHTML = "<input type='button' value='Delete' id='deletesv' onclick='deleteRowSv(this.parentNode.parentNode.rowIndex)'>";
}

		totalspun =0;
		function deleteRowPun(i){
		
		document.getElementById('tabelapun').deleteRow(i)
		
		}
		function adicionapun(){
		totalspun++
		
	//aqui a input hidden de id="totalspun" que est� no fim do form recebe o valor da variavel totalssv

	//cria um objeto de refer�ncia � tag input hidden
	var objetoDados = document.getElementById("totalspun");
	//altera o atributo value desta tag
	objetoDados.value = totalspun;
	
			tbl = document.getElementById("tabelapun")
	
			var novaLinha = tbl.insertRow(-1);
			var novaCelula;
	
			if(totalssv%2==0) cl = "#b0b0b0";
			else cl = "#dadada";
	
			novaCelula = novaLinha.insertCell(0);
	
			novaCelula.style.backgroundColor = cl
	
			novaCelula.innerHTML = "<select name='postogradpun["+totalspun+"]'><option value=''>-</option><option value='cap'>Cap</option><option value='1ten'>1� Ten</option><option value='2ten'>2� Ten</option><option value='asp'>Asp</option><option value='st'>ST</option><option value='1sgt'>1� Sgt</option><option value='2sgt'>2� Sgt</option><option value='3sgt'>3� Sgt</option><option value='t1'>T1</option><option value='cb'>Cb</option><option value='sdnb'>Sd NB</option><option value='sdev'>Sd EV</option></select>";
	
			novaCelula = novaLinha.insertCell(1);
			novaCelula.align = "left";
			novaCelula.style.backgroundColor = cl;
			novaCelula.innerHTML = "<input type='text' name='numeropun["+totalspun+"]' size='1'>";
	
			novaCelula = novaLinha.insertCell(2);
			novaCelula.align = "left";
			novaCelula.style.backgroundColor = cl;
			novaCelula.innerHTML = "<input type='text' name='guerrapun["+totalspun+"]' size='10'>";
			
			novaCelula = novaLinha.insertCell(3);
			novaCelula.align = "left";
			novaCelula.style.backgroundColor = cl;
			novaCelula.innerHTML = "<select name='supun["+totalspun+"]'><option value=''>-</option><option value='em'>EM</option><option value='1bo'>1� BO</option><option value='2bo'>2� BO</option><option value='bc'>BC</option><option value='aae'>AAe</option></select>";
			
			novaCelula = novaLinha.insertCell(4);
			novaCelula.align = "left";
			novaCelula.style.backgroundColor = cl;
			novaCelula.innerHTML = "<select name='punicpun["+totalspun+"]'><option value=''>-</option><option value='id'>ID</option><option value='det'>DET</option><option value='pr'>PR</option></select>";
			
			novaCelula = novaLinha.insertCell(5);
			novaCelula.align = "left";
			novaCelula.style.backgroundColor = cl;
			novaCelula.innerHTML = "<input type='text' name='ndiaspun["+totalspun+"]' size='1'>";
			
			novaCelula = novaLinha.insertCell(6);
			novaCelula.align = "left";
			novaCelula.style.backgroundColor = cl;
			novaCelula.innerHTML = "<input type='text' name='inipun["+totalspun+"]' size='2'>";
			
			novaCelula = novaLinha.insertCell(7);
			novaCelula.align = "left";
			novaCelula.style.backgroundColor = cl;
			novaCelula.innerHTML = "<input type='text' name='terpun["+totalspun+"]' size='2'>";
			
			novaCelula = novaLinha.insertCell(8);
			novaCelula.align = "left";
			novaCelula.style.backgroundColor = cl;
			novaCelula.innerHTML = "<input type='text' name='bipun["+totalspun+"]' size='2'>";
			
			novaCelula = novaLinha.insertCell(9);
			novaCelula.align = "left";
			novaCelula.style.backgroundColor = cl;
			novaCelula.innerHTML = "<input type='button' value='Del' id='deletepun' onclick='deleteRowPun(this.parentNode.parentNode.rowIndex)'>";




    }
	
	
    </script>

<? echo'

</head>
<body>

<form action="novo2.php" method="post" enctype="multipart/form-data" name="form">
  <div align="center">
    <table width="512" border="0">
		<tr>
        <td>Of De Dia:</td>
        <td><label>';
		
		echo '<select name="ofdiaposto">
				<option value="1ten">1� Ten</option>
				<option value="2ten">2� Ten</option>
				<option value="asp">Asp</option>
          </select>';
		echo '
        </label>
		
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	  
       Nome Completo:
        <label>
		<input type="text" name="ofdianome" size="25" value= "">
        </label></td>
      </tr>
		<tr>
			<td colspan="2">
		
		<input type="hidden" name="idusuario" value= "'.$idusuario.'">
		
		<center>Data de In�cio:
		<label>';
		echo '&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="diainicio" size="4" maxlength="2" maxsize="2" value="">';
		echo '&nbsp;/&nbsp;';
		echo '<input type="text" name="mesinicio" size="4" maxlength="2" maxsize="2" value="">';
		echo '&nbsp;/&nbsp;';
		echo '<input type="text" name="anoinicio" size="8" maxlength="4" maxsize="4" value="">';

		echo '
        </label>
		</td>
		</tr>
		<tr>
		<td colspan="2"><center>Data de T�rmino:<label>';
		
		echo '&nbsp;<input type="text" name="diatermino" size="4" maxlength="2" maxsize="2" value= "">';
		echo '&nbsp;/&nbsp;';
		echo '<input type="text" name="mestermino" size="4" maxlength="2" maxsize="2" value= "">';
		echo '&nbsp;/&nbsp;';
		echo '<input type="text" name="anotermino" size="8" maxlength="4" maxsize="4" value= "">';

		echo '
        </label></td>
      </tr>
	  <tr>
        <td>Recibi do:</td>
        <td><label>';
		
		echo '<select name="recebipostograd">
				<option value="1ten">1� Ten</option>
				<option value="2ten">2� Ten</option>
				<option value="asp">Asp</option>
          </select>';
		echo '
        </label>
		
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	  
       Nome de Guerra:
        <label>';
		
		echo '<input type="text" name="recebinome" size="25" value= "">';
		echo '
        </label></td>
      </tr>
	  <tr><td colspan="2"><hr></td></tr>
	  <tr>
        <td width="72">Parada Di�ria:</td>
        <td width="430"><label>';
		
		echo '<select name="parada">
				<option value="s1">A cargo do Ch 1� Sec</option>
				<option value="of">A cargo do Of de Dia</option>
          </select>';
		echo '
        </label></td>
      </tr>
	    <tr>
        <td width="72">Altera��es na Parada:</td>
        <td width="430"><label>';
		
		echo '<textarea name="alterparada" cols="45" rows="2" >N�o houve</textarea>';
		echo '
        </label></td>
      </tr>
	   <tr>
        <td width="72">Correspond�ncia:</td>
        <td width="430"><label>';
		
		echo '<textarea name="correspondencia" cols="45" rows="2" >N�o houve Recebimento</textarea>';
		echo '
        </label></td>
      </tr>
	  <tr>
        <td width="72">Apresenta��o de Militar:</td>
        <td width="430"><label>';
		
		echo '<textarea name="apresmil" cols="45" rows="2" >N�o Houve Apresenta��o</textarea>';
		echo '
        </label></td>
      </tr>
	  <tr><td colspan="2"><hr></td></tr>
	  <tr>
        <td width="72">Ronda Interna:</td>
        <td width="430"><label>';
		
		echo '<textarea name="rondaint" cols="45" rows="2">Sem Altera��o</textarea>';
		echo '
        </label></td>
      </tr>
	  <tr>
        <td width="72">Ronda Externa:</td>
        <td width="430"><label>';
		
		echo '<textarea name="rondaext" cols="45" rows="2">N�o Houve</textarea>';
		echo '
        </label></td>
      </tr>
	  <tr>
        <td width="72">Revista do Recolher:</td>
        <td width="430"><label>';
		
		echo '<select name="revistarec">
				<option value="sa">Sem altera��o</option>
				<option value="ca">Com altera��o</option>
          </select>';
		echo '
        </label></td>
      </tr>
	  <tr>
        <td width="72">Altera��o na Revista do Recolher:</td>
        <td width="430"><label>';
		
		echo '<textarea name="alterrevrec" cols="45" rows="2">Sem Altera��o</textarea>';
		echo '
        </label></td>
      </tr>
	  <tr><td colspan="2"><hr></td></tr>
      <tr>
	  <td colspan="2">
	  
	 Pessoal de SV
	   
	 <table id="tabelasv" border="0" width="100%">
        <tr style="background-color:#b0b0b0">
            <td>Fun��o</td>
			<td>Posto/Grad</td>
            <td>Nome</td>
            <td>Deletar</td>
        </tr>
    </table>
<br />
<input type="button" id="incluirsv" value="incluir" onclick="adicionasv()"/>
<input type="hidden" id="totalssv" name="totalssv" value="" />	 
<hr>
      Puni��es
	  <table id="tabelapun" border="0" width="100%">
        <tr style="background-color:#b0b0b0">
            <td>P/Grad</td>
			<td>Num</td>
            <td>Nome</td>
			<td>SU</td>
			<td>Punic</td>
			<td>Dias</td>
			<td>Ini</td>
			<td>Ter</td>
			<td>BI</td>
            <td>Del</td>
        </tr>
    </table>
	<br />
	<input type="button" id="incluirpun" value="incluir" onclick="adicionapun()"/>
	<input type="hidden" id="totalspun" name="totalspun" value="" />
  
	  </td>
	  </tr>
	  <tr><td colspan="2"><hr></td></tr>
	  <tr>
        <td width="72">Ocorr�ncias:</td>
        <td width="430"><label>';
		
		echo '<textarea name="ocorrencias" cols="45" rows="20">Sem Altera��o</textarea>';
		echo '
        </label></td>
      </tr>  
	  <tr>
		<td colspan="2"><hr><br><center><strong>Parte ao Fiscal Administrativo</strong><br><hr></td>
	  </tr>
	  <tr>
        <td width="72">Material Carga:</td>
        <td width="430"><label>';
		
		echo '<textarea name="famatcarga" cols="45" rows="2">Sem Altera��o</textarea>';
		echo '
        </label></td>
      </tr> 
	  <tr>
        <td width="72">Depend�ncias:</td>
        <td width="430"><label>';
		
		echo '<textarea name="fadependencias" cols="45" rows="2">Sem Altera��o</textarea>';
		echo '
        </label></td>
      </tr> 
	  <tr>
        <td width="72">Tel e Alarmes:</td>
        <td width="430"><label>';
		
		echo '<textarea name="fatelalarmes" cols="45" rows="2">Sem Altera��o</textarea>';
		echo '
        </label></td>
      </tr> 
	  <tr>
		<td colspan="2"><hr></td>
	  </tr>
	  <tr>
		<td colspan="2">Leitura de Energia:</td>
	  </tr>
	  <tr>
	  	<td width="72">Consumo:</td>
        <td><label>
		<input type="text" name="faenergiaconsumo" size="15" value= "">
        </label></td>
      </tr>
	  <tr>
	  	<td width="72">Demanda:</td>
        <td><label>
		<input type="text" name="faenergiademanda" size="15" value= "">
        </label></td>
      </tr>
	  <tr>
        <td width="72">Clavicul�rio:</td>
        <td width="430"><label>';
		
		echo '<textarea name="faclaviculario" cols="45" rows="2">Sem Altera��o</textarea>';
		echo '
        </label></td>
      </tr>
	  <tr>
		<td colspan="2"><hr></td>
	  </tr> 
	  <tr>
        <td width="72">Abastecimento:</td>
        <td width="430"><label>';
		
		echo '<select name="faabastecimento">
				<option value="N�o Houve">N�o Houve</option>
				<option value="Houve">Houve</option>
          </select>';
		echo '
        </label></td>
      </tr>
	  <tr>
		<td colspan="2">VTR de Dia:</td>
	  </tr>
	  <tr>
	  	<td colspan="2">
			<table border="1">
				<tr>
					<td>
						<center>Ton</center>
					</td>
					<td>
						<center>EB</center>
					</td>
					<td>
						<center>Od Sa�da</center>
					</td>
					<td>
						<center>Od Chegada</center>
					</td>
					<td>
						<center>Diferen�a</center>
					</td>
					<td>
						<center>Obs</center>
					</td>
				</tr>
				<tr>
					<td>
					   <label>
					      <select name="favtrton">
								<option value="3/4">3/4</option>
								<option value="1/4">1/4</option>
								<option value="5">5</option>
								<option value="2,5">2,5</option>
								<option value="Adm">Adm</option>
						  </select>
						</label>
					</td>
					<td>
						<label>
							<input type="text" name="favtreb" size="9" value= "">
        				</label>
					</td>
					<td>
						<label>
							<input type="text" name="favtrodsaida" size="4" value= "">
        				</label>
					</td>
					<td>
						<label>
							<input type="text" name="favtrodchegada" size="4" value= "">
        				</label>
					</td>
					<td>
						<label>
							<input type="text" name="favtrdiferenca" size="5" value= "">
        				</label>
					</td>
					<td>
						<label>
							<textarea name="favtrobs" cols="15" rows="1">Sem Altera��o</textarea>
       					 </label>
					</td>
				</tr>
			</table>
		
		<td>
	  </tr>
	  <tr>
		<td colspan="2"><hr></td>
	  </tr>
	  <tr>
        <td width="72">Po�o Artesiano:</td>
        <td width="430">
			<label>
				<textarea name="fapocoartesiano" cols="45" rows="2">Sem Altera��o</textarea>
        	</label>
		</td>
      </tr> 
	  <tr>
        <td width="72">Luzes de Emerg�ncia:</td>
        <td width="430">
			<label>
				<textarea name="faluzemergencia" cols="45" rows="2">Sem Altera��o</textarea>
        	</label>
		</td>
      </tr> 
	  <tr>
		<td colspan="2"><hr></td>
	  </tr>
	  <tr>
		<td colspan="2">Rancho:</td>
	  </tr>
	  <tr>
	  	<td width="72">Sobras:</td>
        <td><label>
		<input type="text" name="faransobras" size="15" value= "">&nbsp;Kg
        </label></td>
      </tr>
	  <tr>
	  	<td width="72">Res�duos:</td>
        <td><label>
		<input type="text" name="faranresiduos" size="15" value= "">&nbsp;Kg
        </label></td>
      </tr>
	  <tr>
        <td width="72">Arranchamento:</td>
        <td width="430">
			<label>
				<textarea name="faranarranchamento" cols="45" rows="2">Sem Altera��o</textarea>
        	</label>
		</td>
      </tr>
	  <tr>
        <td width="72">Defesa Alimentar:</td>
        <td width="430">
			<label>
				<textarea name="farangeneros" cols="45" rows="2">Nada Houve</textarea>
        	</label>
		</td>
      </tr>
	  <tr>
		<td colspan="2"><hr></td>
	  </tr>
	  <tr>
        <td width="72">Muni��o:</td>
        <td width="430">
			<label>
				<textarea name="famunicao" cols="45" rows="2">Sem Altera��o</textarea>
        	</label>
		</td>
      </tr>
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  <tr>
        <td width="72">Passei ao:</td>
        <td width="430"><label>';
		
		echo '<select name="passeipostograd">
				<option value="1ten">1� Ten</option>
				<option value="2ten">2� Ten</option>
				<option value="asp">Asp</option>
          </select>';
		echo '
        </label>
		
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	  
        Nome de Guerra:
        <label>';
		
		echo '&nbsp;<input type="text" name="passeinome" size="15" value= "">';
		echo '
        </label></td>
      </tr>
	 <tr>
        <td colspan="2"><br><p><center>Adjunto ao Oficial de Dia: 
		';
		//corrigindo o posto
		switch ($postograd){
			case '1sgt':
				$postograd='1� SGT';
				break;
			case '2sgt':
				$postograd='2� SGT';
				break;
			case '3sgt':
				$postograd='3� SGT';
				break;	
				}  
		
		echo $postograd; echo '&nbsp;';	echo convertem($guerra, 1); echo '</p><label>
		<input type="hidden" name="postograd" size="15" value= "'.$postograd.'">
		<input type="hidden" name="guerra" size="15" value= "'.$guerra.'">';
		echo '
        </label></td>
      </tr>
	   
    </table>
    <p>
      <label>
      <input type="submit" name="button" id="button" value="Salvar">
      </label>
    </p>
  </div>
</form>
<p align="center">&nbsp;</p>
</body>
</html>';
}
else
{
	echo '<center> Usu�rio n�o encontrado!<br> <a href="alterarmatricula.html" target="Display">Voltar</a>';
}
}
	else
		{
			echo '<center>Usuario n�o autorizado!';
		}
}
else
{
	echo '<center>Usuario n�o autorizado!';
}
?>
