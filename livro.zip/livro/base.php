<?
	$conexaolivro = mysql_connect('localhost','root','$1343esa$');
	mysql_select_db('livro',$conexaolivro);
?>
