<?
session_start();
include "base.php";
if (isset($_SESSION['nivel'])) 
{
 	$logado = $_SESSION['nivel'];
  	if ($logado == '3')
	{
	$idusuario = $_SESSION['id'];
	$idlivro = $_GET['idlivro'];
	//selecionando dados do usuario
	$result = mysql_query("SELECT * FROM livro WHERE id LIKE '%".$idlivro."%';",$conexaolivro);
	$Quantos = mysql_num_rows($result);
	if($Quantos > 0)
	{

	//iniciando vari�veis
			$idusuario = mysql_result($result,0,idusuario);
			$diainicio = mysql_result($result,0,diainicio);
			$mesinicio = mysql_result($result,0,mesinicio);;
			$anoinicio = mysql_result($result,0,anoinicio);
			$diatermino = mysql_result($result,0,diatermino);
			$mestermino = mysql_result($result,0,mestermino);
			$anotermino = mysql_result($result,0,anotermino);	
			$ofdiaposto = mysql_result($result,0,ofdiaposto); 
			$ofdianome = mysql_result($result,0,ofdianome);
			$adjgrad = mysql_result($result,0,adjgrad);
			$adjnome = mysql_result($result,0,adjnome);
			?>
			<script LANGUAGE="JavaScript">
			
			function show(variavel){
			if(document.getElementById(variavel).style.display == 'block'){
			document.getElementById(variavel).style.display = 'none';
			}else{
			document.getElementById(variavel).style.display = 'block';
			}
			}
			</SCRIPT>
			
			
<?	
echo '

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Livro</title>


</head>
<body>
<form id="form1" name="form1" method="post" action="despachar2.php">
  <div align="center">
    <p>Despacho Para o Livro</p>
	<p>C�digo: ';echo $idlivro; echo'<br>Data: '; echo $diainicio; echo '/'; echo $mesinicio; echo '/'; echo $anoinicio; echo '<br>Of de Dia: '; 
	
	switch($ofdiaposto){
					case '1ten': echo '1� Ten';
					break;
					case '2ten': echo '2� Ten';
					break;
					case 'asp': echo 'Asp';
					break;
				}
	echo '&nbsp;'; echo $ofdianome; echo'</p>
    <table width="200" border="0">
      <tr>
        <td height="106">Fiscal</td>
        <td><label>
          <input name="fiscalcheck" type="checkbox" id="fiscalcheck" value="sim" onClick="show('."'fiscal'".')"/>
        </label></td>
        <td>
		<DIV id="fiscal" style="display:none;">
		
		<textarea name="fiscaldespacho" cols="50" rows="5" id="fiscaldespacho"></textarea>
		
		</DIV>
		</td>
      </tr>
	  <tr>
        <td height="106">S1</td>
        <td><label>
          <input name="s1check" type="checkbox" id="s1check" value="sim" onClick="show('."'s1'".')"/>
        </label></td>
        <td>
		<DIV id="s1" style="display:none;">
		
		<textarea name="s1despacho" cols="50" rows="5" id="s1despacho"></textarea>
		
		</DIV>
		</td>
      </tr>
      <tr>
        <td height="106">S2</td>
        <td><label>
          <input name="s2check" type="checkbox" id="s2check" value="sim" onClick="show('."'s2'".')"/>
        </label></td>
        <td>
		<DIV id="s2" style="display:none;">
		
		<textarea name="s2despacho" cols="50" rows="5" id="s2despacho"></textarea>
		
		</DIV>
		</td>
      </tr>
     <tr>
        <td height="106">S3</td>
        <td><label>
          <input name="s3check" type="checkbox" id="s3check" value="sim" onClick="show('."'s3'".')"/>
        </label></td>
        <td>
		<DIV id="s3" style="display:none;">
		
		<textarea name="s3despacho" cols="50" rows="5" id="s3despacho"></textarea>
		
		</DIV>
		</td>
      </tr>
      <tr>
        <td height="106">S4</td>
        <td><label>
          <input name="s4check" type="checkbox" id="s4check" value="sim" onClick="show('."'s4'".')"/>
        </label></td>
        <td>
		<DIV id="s4" style="display:none;">
		
		<textarea name="s4despacho" cols="50" rows="5" id="s4despacho"></textarea>
		
		</DIV>
		</td>
      </tr>
	  <tr>
        <td height="106">1� BO</td>
        <td><label>
          <input name="bo1check" type="checkbox" id="bo1check" value="sim" onClick="show('."'bo1'".')"/>
        </label></td>
        <td>
		<DIV id="bo1" style="display:none;">
		
		<textarea name="bo1despacho" cols="50" rows="5" id="bo1despacho"></textarea>
		
		</DIV>
		</td>
      </tr>
	  <tr>
        <td height="106">2� BO</td>
        <td><label>
          <input name="bo2check" type="checkbox" id="bo2check" value="sim" onClick="show('."'bo2'".')"/>
        </label></td>
        <td>
		<DIV id="bo2" style="display:none;">
		
		<textarea name="bo2despacho" cols="50" rows="5" id="bo2despacho"></textarea>
		
		</DIV>
		</td>
      </tr>
	  <tr>
        <td height="106">BC</td>
        <td><label>
          <input name="bccheck" type="checkbox" id="bccheck" value="sim" onClick="show('."'bc'".')"/>
        </label></td>
        <td>
		<DIV id="bc" style="display:none;">
		
		<textarea name="bcdespacho" cols="50" rows="5" id="bcdespacho"></textarea>
		
		</DIV>
		</td>
      </tr>
	  <tr>
        <td height="106">AAe</td>
        <td><label>
          <input name="aaecheck" type="checkbox" id="aaecheck" value="sim" onClick="show('."'aae'".')"/>
        </label></td>
        <td>
		<DIV id="aae" style="display:none;">
		
		<textarea name="aaedespacho" cols="50" rows="5" id="aaedespacho"></textarea>
		
		</DIV>
		</td>
      </tr>
    </table>
    <p><center>
      <label>
      <input name="idlivro" type="hidden" id="idlivro" value="'.$idlivro.'" />
	  <input name="Despachar" type="submit" id="Despachar" value="Despachar" />
      </label>
    </p>
    <p>
      <label></label>
      <label></label>
    </p>
  </div>
</form>
</body>
</html>';
}
else
{
	echo '<center> Usu�rio n�o encontrado!';
}
}
	else
		{
			echo '<center>Usuario n�o autorizado!';
		}
}
else
{
	echo '<center>Usuario n�o autorizado!';
}
?>