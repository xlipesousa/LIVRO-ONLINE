<?
include "base.php";
session_start("usuarios");
$logado = $_SESSION['nivel'];
if ($logado == '1')
		{
		$iduser = $_SESSION['id'];
		?>
		<html>
			<head>
			<title>Alterar Usuario</title>
			<script>function checar(pagina,texto) { if (confirm("DSEJA REALMENTE ALTERARA SENHA DESTE USUARIO?")==true) { window.location=pagina; } }</script>
			<script language="JavaScript">
				function mudacelula(){
					var cor = "#FFFF75";
					var elemento = document.getElementById("teste");
					elemento.style.backgroundColor = cor;
				}
			</script>
			</head>

		<body>
		<table width="500" height="97" border="0" cellpadding="0" cellspacing="0">
           <tr> 
               <td valign="top"><div align="center"><img src="../sfpc/imagens/cadeado.jpg"></div></td>
  			</tr>
  			<tr> 
   			<td height="19"> 
				  <?php
				$sql = "SELECT id, postograd, guerra FROM usuarios WHERE nivel > 1 ORDER BY postograd DESC";
				$qry = mysql_query($sql, $conexaolivro);
				$totalreg = mysql_num_rows($qry);
				$i = 0; 
				?>
      			<div align="center"> 
                        <table width="540" border="0" cellpadding="0" cellspacing="0" bgcolor="#999999">
							<tr>
								<td width="95"><center>Posto/Grad
								</td>
								<td width="120"><center>Nome
								</td>
								<td width="80"> <center>Senha
								</td>
							</tr>
							<?php
							if ($totalreg < 1){
							echo "<tr><td width=\"440\"><div align=\"center\"><font class=\"font1\"><i><br><br>Nenhum <u>Usu�rio</u> Encontrado!</i></font></div></td></tr>";
							}
							else
							{
							
					while ($reg = mysql_fetch_array($qry, MYSQL_ASSOC)){
							$idusuario = mysql_result($qry,$i,id);
							if($idusuario != "x")
							{
														
							$postograd = mysql_result($qry,$i,postograd);
							$guerra = mysql_result($qry,$i,guerra);
														
							//corrigindo o posto 
							switch ($postograd){
								case 'cel':
									$postogradselect='Cel';
									break;
								case 'tc':
									$postogradselect='TC';
									break;
							case 'maj':
      							$postogradselect='Maj';
     								break;
								case 'cap':
      								$postogradselect='Cap';
     								break;
								case '1ten':
      								$postogradselect='1� Ten';
     								break;
								case '2ten':
      								$postogradselect='2� Ten';
     								break;
								case 'asp':
      								$postogradselect='Asp';
     								break;
								case 'st':
      								$postogradselect='ST';
     								break;
								case '1sgt':
      								$postogradselect='1� Sgt';
     								break;
								case '2sgt':
      								$postogradselect='2� Sgt';
     								break;
								case '3sgt':
      								$postogradselect='3� Sgt';
     								break;
									}

									
					?>
						   <tr id="teste" onMouseOver="this.style.backgroundColor='#C1FFC1'" onMouseOut="this.style.backgroundColor='<?=($i % 2 == 0 ? "#F7F7F7" : "#E6E6E6")?>'" bgcolor="<?=($i % 2 == 0 ? "#F7F7F7" : "#E6E6E6")?>"> 
						   
						   
							<td  height="19"><font class="font1"><center><?php echo $postogradselect; ?></font></td>
							
							
							<td  height="19"><font class="font1"><center><?php echo $guerra; ?></font></td>
							
							
							<td width="36"><div align="center"><a href="../sfpc/senhausuario2.php?idusuario=<?php echo $idusuario; ?>"><img src="../sfpc/imagens/chave.jpg" border="0" alt="Ler"></a></div></td>
						  </tr>
						  <?php
						  	}
							$i++;
						}
					}
					?>
						</table><p></p>
      </div></td>
  </tr>
</table>
			
		</body>
		</html>
		
		
		
		
	
<?
		}
	else
	{echo '
	<htm>
<head>
<title>Militares Cadastrados</title>
</head>
<body>
	<center>Usuario n�o autorizado!
	
	</body>
</html>';

	}
	?>