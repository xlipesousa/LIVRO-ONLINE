<?
 session_start("usuarios");
 if(isset($_SESSION['nivel']))
 
 {
 $_SESSION['niel'] = NULL; 
 session_unset("usuarios");
 session_unregister("usuarios");
session_destroy();
 }
 echo'<center><br><br><br><br><br><br><br><br>Se��o Terminada com sucesso<br>';
 echo'Clique ';
 echo'<a href="index.php">AQUI </a>';
 echo'Para retornar � pagina principal</center>';

?>
