<?
include "base.php";
session_start("usuarios");
$logado = $_SESSION['nivel'];
if ($logado)
{	
	$idusuario = $_POST["idusuario"];
	$atual = $_POST["atual"];
	$nova = $_POST["nova"];
	$confirma = $_POST["confirma"];
	if ($nova == $confirma)
	{
		$busca = mysql_query("SELECT senha FROM usuarios where id='".$idusuario."';", $conexaolivro);
		if ($busca)
		{
			$senha	= mysql_result($busca,0,$senha);
			if($senha == $atual)
			{
				$altera = mysql_query("UPDATE usuarios SET senha = '".$nova."' WHERE id='".$idusuario."';",$conexaolivro);
				if ($altera)
				{
					echo'<center>Senha Alterada com Sucesso!<br>';
				}
				else
				{
					echo'<center>Erro ao Alterar Senha!<br>';
				}	
			}
			else
			{
				echo' <center> Erro ao tentar alterar senha! <br>Senha Atual Inv�lida!<br>';
			}
		}
		else
		{
			echo' <center> Erro ao tentar alterar senha! <br>Senha Atual Inv�lida!<br>';
		}	
	}
	else
	{
		echo' <center> Erro ao tentar alterar senha! <br>Nova senha diferente da confirma��o!<br>';
	}
}
else
{
	echo '
	<html>
		<head>Alterar Senha</title>
		</head>
		<body>
			<center>Usuario n�o autorizado!
		</body>
	</html>';
}
?>
