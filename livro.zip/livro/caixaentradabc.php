<?
include "base.php";
session_start("usuarios");
$logado = $_SESSION['nivel'];
if ($logado == '9')
		{
		?>
		<html>
			<head>
			<title>Caixa de entrada</title>
			<script>function checar(pagina,texto) { if (confirm("DSEJA REALMENTE DELETAR ESTE LIVRO?")==true) { window.location=pagina; } }</script>
			<script language="JavaScript">
				function mudacelula(){
					var cor = "#FFFF75";
					var elemento = document.getElementById("teste");
					elemento.style.backgroundColor = cor;
				}
			</script>
			</head>

		<body>
		<table width="500" height="97" border="0" cellpadding="0" cellspacing="0">
           <tr> 
               <td valign="top"><div align="center"><img src="../livro/imagens/livro.jpg"></div></td>
  			</tr>
  			<tr> 
   			<td height="19"> 
				  <?php
				$sql = "SELECT id, diainicio, mesinicio, anoinicio, ofdiaposto, ofdianome FROM livro where bccheck = 'n' ORDER BY id DESC";
				$qry = mysql_query($sql, $conexaolivro);
				$totalreg = mysql_num_rows($qry);
				$i = 0; 
				?>
      			<div align="center"> 
                        <table width="540" border="0" cellpadding="0" cellspacing="0" bgcolor="#999999">
							<tr>
								<td width="75"><center>Cod Livro
								</td>
								<td width="100"><center>Data SV
								</td>
								<td width="120"><center>Of Dia
								</td>
								<td width="80"><center>Anota��o
								</td>
								<td width="80"><center>Ler
								</td>
							</tr>
							<?php
							if ($totalreg < 1)
							{
							echo "<tr><td width=\"440\"><div align=\"center\"><font class=\"font1\"><i><br><br>Caixa de Entrada<u>Vazia!</u></i></font></div></td></tr>";
							}
							else 
							{
							
					while ($reg = mysql_fetch_array($qry, MYSQL_ASSOC)){
							$idlivro = mysql_result($qry,$i,id);
							$diainicio = mysql_result($qry,$i,diainicio);
							$mesinicio = mysql_result($qry,$i,mesinicio);
							$anoinicio = mysql_result($qry,$i,anoinicio);
							$ofdiaposto = mysql_result($qry,$i,ofdiaposto);
							$ofdianome = mysql_result($qry,$i,ofdianome);
							
							//corrigindo o posto do of dia
							switch ($ofdiaposto){
								case '1ten':
      								$ofdiaposto='1� Ten';
     								break;
								case '2ten':
      								$ofdiaposto='2� Ten';
     								break;
								case 'asp':
      								$ofdiaposto='Asp';
     								break;
									}
									
							//corrigindo despacho
							switch ($despachado){
								case 's':
      								$despachado='Sim';
     								break;
								default :
      								$despachado='N�o';
     								break;
									}		
					?>
						   <tr id="teste" onMouseOver="this.style.backgroundColor='#C1FFC1'" onMouseOut="this.style.backgroundColor='<?=($i % 2 == 0 ? "#F7F7F7" : "#E6E6E6")?>'" bgcolor="<?=($i % 2 == 0 ? "#F7F7F7" : "#E6E6E6")?>"> 
						   
						   
							<td  height="19"><font class="font1"><center><?php echo $idlivro; ?></font></td>
							
							
							<td  height="19"><font class="font1"><center><?php echo $diainicio; echo'/';echo $mesinicio; echo'/'; echo $anoinicio; ?></font></td>
							
							
							<td width="80" height="19"><font class="font1"><center><?php echo $ofdiaposto; echo'&nbsp;'; echo $ofdianome; ?></font></td>
							
							<?
							echo "<td width='36'><div align='center'><a href='../livro/anotacaobc.php?idlivro="; echo $idlivro; echo "'  ><img src='../livro/imagens/despachar.png' border='0' alt='Anota��o' ></a></div></td>";
							?>
							
							
							<td width="36"><div align="center"><a target ='_blank' href="../livro/lerlivro.php?idlivro=<?php echo $idlivro; ?>"><img src="../livro/imagens/ler.png" border="0" alt="Ler"></a></div></td>
						  </tr>
						  <?php
					$i++;
						}
					}
					?>
						</table><p></p>
      </div></td>
  </tr>
</table>
			
		</body>
		</html>
		
		
		
		
	
<?
		}
	else
	{echo '
	<htm>
<head>
<title>Caixa de Entrada</title>
</head>
<body>
	<center>Usuario n�o autorizado!
	
	</body>
</html>';

	}
	?>