<?
session_start();
include "base.php";
include "basesisau.php";
if (isset($_SESSION['nivel'])) 
{
 	$logado = $_SESSION['nivel'];
	$id = $_SESSION['id'];
  	if (($logado == '1')||($logado == '2'))
	{		
		echo'<html>
		<head>
		<title>Plano de Chamada por Cidade</title>
		</head>
		<body>';
		$cidade = $HTTP_POST_VARS['cidade'];		
		//pesquisando no banco		
		$result = mysql_query("SELECT * FROM cadastro WHERE cidade = '".$cidade."' order by su desc;",$conexaosisau);
       
		$Quantos = mysql_num_rows($result);
		if($Quantos > 0)
			{
			
				//cabe�alho
				
        echo'<center>Plano de Chamada de Militares de ';
		echo $cidade;
		echo' Ordenados por SU ';

		echo '<br><br><center>Total de registros encontrados: ';
		echo $Quantos;		
				
				//formatando a tabela de destinos
				echo'
    <table width="524" border="1">
      
      <tr>
        <td width="200"><div align="center">Nome</div></td>
        <td width="80"><div align="center">SU</div></td>
		<td width="100"><div align="center">Bairro</div></td>
        <td width="70"><div align="center">Tel1</div></td>
        <td width="70"><div align="center">Tel2</div></td>
        <td width="58"><div align="center">Detalhes</div></td>
      </tr>
      <tr>';
//preenchendo a tabela	  
		$i=0;
			for ($i==0; $i<$Quantos; $i++)
						{
							$su = mysql_result($result,$i,su);
							$bairro = mysql_result($result,$i,bairro);
							$tel1 = mysql_result($result,$i,tel1);
							$tel2 = mysql_result($result,$i,tel2);
							$id = mysql_result($result,$i,id);
							echo '<td>';
							$consulta = mysql_query("SELECT nome FROM usuarios WHERE id like '".$id."';",$conexaolivro);

							if (mysql_num_rows($consulta) > 0) {
								$nome = mysql_result($consulta,0,nome);
								if (isset($id) && (!isset($nome))) {
								}
							}
							echo $nome;
							echo'</td>';
							echo '<td>';
							echo $su.".";
							echo'</td>';
							echo '<td>';
							echo $bairro.".";
							echo'</td>';
							echo '<td>';
							echo $tel1.".";
							echo'</td>';
							echo '<td>';
							echo $tel2.".";
							echo'</td>';	
							///link para visualizar o pedido
							echo '<td><center>';
							echo '<form action="planochamadaver.php" method="post" name="form1" target="Display">';
    						echo'<input name="id" type="hidden" id="id" size="7" maxlength="20" value= "'.$id.'">';
    						echo'<input name="nome" type="hidden" id="id" size="7" maxlength="20" value= "'.$nome.'">';
							echo'<input type="submit" name="Submit" value="Ver">
								 </form>';
							echo '</td></tr>';
						}
			
			echo '</table>';
			//bot�es de impress�o
			
			echo'<br><br><center> Vers�es Para Impress�o<br><br>';
			echo '<form action="planocidaderesumido.php" method="post" name="form1" target="_blanck">';
    						echo'<input name="cidade" type="hidden" id="id" size="7" maxlength="20" value= "'.$cidade.'">';
							echo'<input type="submit" name="Submit" value="Resumido">
				 </form>';
			echo '<form action="planocidadecompleto.php" method="post" name="form1" target="_blanck">';
    						echo'<input name="cidade" type="hidden" id="id" size="7" maxlength="20" value= "'.$cidade.'">';
							echo'<input type="submit" name="Submit" value="Completo">
				 </form>';

			}

				//fim da tabela de destinos
		else
			{
				echo '<center>Nenhum registro encontrado para este per�odo.';
			}
	
	}
	else
	{
		echo '<center>Usuario n�o autorizado!';
	}
}
else
{
	echo '<center>Usuario n�o autorizado!';
}
?>
</body>
</html>
