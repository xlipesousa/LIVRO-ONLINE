<?
include "base.php";
session_start("usuarios");
$logado = $_SESSION['nivel'];
if ($logado == '1')
		{
		$iduser = $_SESSION['id'];
		?>
		<html>
			<head>
			<title>Excluir Usu�rios</title>
			<script>function checar(pagina,texto) { if (confirm("DSEJA REALMENTE DELETAR ESTE USU�RIO?")==true) { window.location=pagina; } }</script>
			<script language="JavaScript">
				function mudacelula(){
					var cor = "#FFFF75";
					var elemento = document.getElementById("teste");
					elemento.style.backgroundColor = cor;
				}
			</script>
			</head>

		<body>
		<table width="500" height="97" border="0" cellpadding="0" cellspacing="0">
           <tr> 
               <td valign="top"><div align="center"><img src="../livro/imagens/usuario.jpg"></div></td>
  			</tr>
  			<tr> 
   			<td height="19"> 
				  <?php
				$sql = "SELECT * FROM usuarios WHERE nivel <='6' ORDER BY id DESC";
				$qry = mysql_query($sql, $conexaolivro);
				$totalreg = mysql_num_rows($qry);
				$i = 0; 
				?>
      			<div align="center"> 
                        <table width="540" border="0" cellpadding="0" cellspacing="0" bgcolor="#999999">
							<tr>
								<td width="95"><center>Posto/Grad
								</td>
								<td width="120"><center>Nome
								</td>
								<td width="80"> <center>Excluir
								</td>
							</tr>
							<?php
							if ($totalreg < 1){
							echo "<tr><td width=\"440\"><div align=\"center\"><font class=\"font1\"><i><br><br>Nenhum <u>Livro</u> Encontrado!</i></font></div></td></tr>";
							}
							else
							{
							
					while ($reg = mysql_fetch_array($qry, MYSQL_ASSOC)){
							$idusuario = mysql_result($qry,$i,id);
							if($idusuario != "x")
							{
														
							$postograd = mysql_result($qry,$i,postograd);
							$guerra = mysql_result($qry,$i,guerra);
														
							//corrigindo o posto do of dia
							switch ($postograd){
								case 'maj':
      								$postograd='Maj';
     								break;
								case 'cap':
      								$postograd='Cap';
     								break;
								case '1ten':
      								$postograd='1� Ten';
     								break;
								case '2ten':
      								$postograd='2� Ten';
     								break;
								case 'asp':
      								$postograd='Asp';
     								break;
								case 'st':
      								$postograd='ST';
     								break;
								case '1sgt':
      								$postograd='1� Sgt';
     								break;
								case '2sgt':
      								$postograd='2� Sgt';
     								break;
								case '3':
      								$postograd='3� Sgt';
     								break;
									}
									
									
					?>
						   <tr id="teste" onMouseOver="this.style.backgroundColor='#C1FFC1'" onMouseOut="this.style.backgroundColor='<?=($i % 2 == 0 ? "#F7F7F7" : "#E6E6E6")?>'" bgcolor="<?=($i % 2 == 0 ? "#F7F7F7" : "#E6E6E6")?>"> 
						   
						   
							<td  height="19"><font class="font1"><center><?php echo $postograd; ?></font></td>
							
							
							<td  height="19"><font class="font1"><center><?php echo $guerra; ?></font></td>
							
							
							<td width="36"><div align="center"><a href="../livro/excluircadastro.php?idusuario=<?php echo $idusuario; ?>"><img src="../livro/imagens/excluir.png" border="0" alt="Ler"></a></div></td>
						  </tr>
						  <?php
						  	}
							$i++;
						}
					}
					?>
						</table><p></p>
      </div></td>
  </tr>
</table>
			
		</body>
		</html>
		
		
		
		
	
<?
		}
	else
	{echo '
	<htm>
<head>
<title>Meus Livros</title>
</head>
<body>
	<center>Usuario n�o autorizado!
	
	</body>
</html>';

	}
	?>