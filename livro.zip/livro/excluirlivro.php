<?
session_start();
include "base.php";
if (isset($_SESSION['nivel'])) 
{
 		$logado = $_SESSION['nivel'];
  		if ($logado == '2')
		{
			
		if (! isset($_GET['idlivro']))
		{
			echo "<script>alert('Livro n�o selecionado!'); history.back(-1);</script>";
			exit;
		}
	
		$idlivro = $_GET['idlivro'];
		$idlivro = trim(addslashes($idlivro));
	
		//verificando se o livro existe
		$result = mysql_query("SELECT id FROM livro WHERE id LIKE '%".$idlivro."%';",$conexaolivro);
		$Quantos = mysql_num_rows($result);
		if($Quantos < 1)
		{
			echo "<script>alert('Livro N�o Encontrado!'); location.href = 'meuslivros.php';</script>";
			exit;
		} 
		else
		{
				$delete = "DELETE FROM livro WHERE id = '$idlivro'";
				mysql_query($delete, $conexaolivro);
				echo "<script>alert('Livro Deletado Com Sucesso!'); location.href = 'meuslivros.php';</script>";
				exit;
		}
		
		
		}
		else
		{
		echo '<center>Usuario n�o autorizado!';
		}
}
else
{
	echo '<center>Usuario n�o autorizado!';
}	
	?>
</body>
</body>
</html>
