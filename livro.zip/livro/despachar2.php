<?
session_start();
include "base.php";
if (isset($_SESSION['nivel'])) 
{
 	$logado = $_SESSION['nivel'];
	$idusuario = $_SESSION['id'];
  	if ($logado == '3')
	{		
		echo'<html>
		<head>
		<title>Despachar Livro</title>
		</head>
		<body>';
		//recebendo vari�vel
		//retirando as oespa�os e aspas		
		$idlivro= $HTTP_POST_VARS[idlivro];
		$fiscalcheck= $_POST['fiscalcheck'];
        $s1check= $_POST['s1check'];
		$s2check= $_POST['s2check'];
		$s3check= $_POST['s3check'];
		$s4check= $_POST['s4check'];
		$bo1check= $_POST['bo1check'];
		$bo2check= $_POST['bo2check'];
		$bccheck= $_POST['bccheck'];
		$aaecheck= $_POST['aaecheck'];

		
		if($fiscalcheck == "sim")
		{
		
		  $fiscaldespacho= $_POST['fiscaldespacho'];
		  $results1 = mysql_query("UPDATE livro SET fiscaldespacho='". $fiscaldespacho ."', fiscalcheck = 'n' WHERE id='".$idlivro."';",$conexaolivro);

		}
		
		if($s1check == "sim")
		{
		
		  $s1despacho= $_POST['s1despacho'];
		  $results1 = mysql_query("UPDATE livro SET s1despacho='". $s1despacho ."', s1check = 'n' WHERE id='".$idlivro."';",$conexaolivro);

		}
				
		
		if($s2check == "sim")
		{
		
		  $s2despacho= $_POST['s2despacho'];
		  $results2 = mysql_query("UPDATE livro SET s2despacho='". $s2despacho ."', s2check = 'n'  WHERE id='".$idlivro."';",$conexaolivro);

		}
		
		
		if($s3check == "sim")
		{
		
		  $s3despacho= $_POST['s3despacho'];
		  $results3 = mysql_query("UPDATE livro SET s3despacho='". $s3despacho ."', s3check = 'n' WHERE id='".$idlivro."';",$conexaolivro);
		  

		}
		
		if($s4check == "sim")
		{
		
		  $s4despacho= $_POST['s4despacho'];
		  $results4 = mysql_query("UPDATE livro SET s4despacho='". $s4despacho ."', s4check = 'n' WHERE id='".$idlivro."';",$conexaolivro);
		  

		}
		
		if($bo1check == "sim")//nomes de vari�veis n�o podem come�ar com n�mero, por isso inverti 1bo = bo1
		{
		
		  $bo1despacho= $_POST['bo1despacho'];
		  $results5 = mysql_query("UPDATE livro SET bo1despacho='". $bo1despacho ."', bo1check = 'n' WHERE id='".$idlivro."';",$conexaolivro);
		  

		}
		
		if($bo2check == "sim")
		{
		
		  $bo2despacho= $_POST['bo2despacho'];
		  $results6 = mysql_query("UPDATE livro SET bo2despacho='". $bo2despacho ."', bo2check = 'n' WHERE id='".$idlivro."';",$conexaolivro);
		  

		}
		
		if($bccheck == "sim")
		{
		
		  $bcdespacho= $_POST['bcdespacho'];
		  $results7 = mysql_query("UPDATE livro SET bcdespacho='". $bcdespacho ."', bccheck = 'n' WHERE id='".$idlivro."';",$conexaolivro);
		  

		}
		
		if($aaecheck == "sim")
		{
		
		  $aaedespacho= $_POST['aaedespacho'];
		  $results8 = mysql_query("UPDATE livro SET aaedespacho='". $aaedespacho ."', aaecheck = 'n' WHERE id='".$idlivro."';",$conexaolivro);
		  

		}
		
		
		
		
		
		$result = mysql_query("UPDATE livro SET despachado='s' WHERE id='".$idlivro."';",$conexaolivro);
		
		
				if ($result){
				echo '<center>Livro Despachado Com Sucesso!';
				}
				else
				{
					echo '<center>Erro ao Despachar Livro! Contate o Administrador';
				}	
	
		}
			else
				{
					echo '<center>Usuario n�o autorizado!';
				}
		}
else
{
	echo '<center>Usuario n�o autorizado!';
}
?>

</body>
</body>
</html>
