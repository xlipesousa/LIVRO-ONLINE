<?
session_start();
include "base.php";
if (isset($_SESSION['nivel'])) 
{
 	$logado = $_SESSION['nivel'];
  	if ($logado == '1')
	{
echo'
<htm>
<head>
<title>Cadastrar</title>
</head>
<body>
<div align="center">
  <p>Cadastro</p>
</div>
<div align="center">
 <form action="cadastrar2.php" method="post" enctype="multipart/form-data" target="Display" name="cadastrar">
  <div align="center">
    <table width="512" border="0"> 
		<tr>
			<td>Posto/Gradua��o:</td>
			<td><label>
			<select name="postograd">
			  <option value="">Selecione</option>
			  <option value="tc">TC</option>
			  <option value="maj">Maj</option>
			  <option value="cap">Cap</option>
			  <option value="1ten">1� Ten</option>
			  <option value="2ten">2� Ten</option>
			  <option value="asp">Asp</option>
			  <option value="1sgt">1� Sgt</option>
			  <option value="2sgt">2� Sgt</option>
			  <option value="3sgt">3� Sgt</option>
			</select>
			</label></td>
       </tr>
	   <tr>
        <td>Nome de Guerra:</td>
        <td><label>
          <input name="guerra" type="text" size="30"> Ex: Max Wolff
        </label></td>
      </tr>
	   <tr>
        <td>Nome Completo:</td>
        <td><label>
          <input name="nome" type="text" size="30">
        </label></td>
      </tr>
      </tr>
	   <tr>
        <td>Identidade:</td>
        <td><label>
          <input name="idt" type="text" size="30">
        </label></td>
      </tr>
	  <tr>
        <td>Subunidade:</td>
        <td><label>
        <select name="su">
          <option value="0">Selecione</option>
		  <option value="em">EM</option>
          <option value="1bo">1� BO</option>
          <option value="2bo">2� BO</option>
          <option value="bc">BC</option>
          <option value="aae">AAe</option>
        </select>
        </label></td>
      </tr>
      <tr>
        <td>Login:</td>
        <td><label>
          <input type="text" name="login">
        </label></td>
      </tr>
	  <tr>
        <td width="113">Senha:</td>
        <td width="389"><label>
          <input type="password" name="senha">
        </label></td>
      </tr>
	  <tr>
        <td>N�vel de Usu�rio:</td>
        <td><label>
        <select name="nivel">
          <option value="2">Adjunto</option>
		  <option value="3">SCMT</option>
          <option value="1">S1</option>
          <option value="4">S2</option>
          <option value="5">S3</option>
		  <option value="6">S4</option>
          <option value="7">1BO Cmt</option>
		  <option value="8">2BO Cmt</option>
		  <option value="9">BC Cmt</option>
		  <option value="10">AAe Cmt</option>
		  <option value="11">Fiscal</option>
		  
        </select>
        </label></td>
      </tr>
    </table>
    <p>
      <label>
      <input type="submit" name="Submit" value="Salvar">
      </label>
    </p>
  </div>
</form>
</body>
</html>';
}
	else
		{
			echo '<center>Usuario n�o autorizado!';
		}
}
else
{
	echo '<center>Usuario n�o autorizado!';
}

?>
