<?
session_start();
include "base.php";
if (isset($_SESSION['nivel'])) 
{
 	$logado = $_SESSION['nivel'];
	$idusuario = $_SESSION['id'];
  	if ($logado == '2')
	{		
		echo'<html>
		<head>
		<title>Novo Livro</title>
		</head>
		<body>';
		
		
		
		//recebendo o total de linhas da tabela sv incluindo as que foram deletadas
		$totalssv=$_POST['totalssv'];
		
		//recebendo o total de linhas da tabela punicao incluindo as que foram deletadas
		$totalspun=$_POST['totalspun'];
		
		//recebendo variável		
		$idusuario = $HTTP_POST_VARS[idusuario];
		$diainicio = $HTTP_POST_VARS[diainicio];
		$mesinicio = $HTTP_POST_VARS[mesinicio];
		$anoinicio = $HTTP_POST_VARS[anoinicio];
		$diatermino = $HTTP_POST_VARS[diatermino];
		$mestermino = $HTTP_POST_VARS[mestermino];
		$anotermino = $HTTP_POST_VARS[anotermino];	
		//retirando as oespaços e aspas
		$ofdiaposto = str_replace(" ", "%", $HTTP_POST_VARS[ofdiaposto]); 
		$ofdianome = $HTTP_POST_VARS[ofdianome];
		$recebipostograd = str_replace(" ", "%", $HTTP_POST_VARS[recebipostograd]); 
		$recebinome = $HTTP_POST_VARS[recebinome];
		$parada = str_replace(" ", "%", $HTTP_POST_VARS[parada]); 
		$alterparada = $_POST['alterparada'];
		$correspondencia = $_POST['correspondencia'];
		$apresmil = $_POST['apresmil'];
		$rondaint = $_POST['rondaint'];
		$rondaext = $_POST['rondaext'];
		$revistarec = str_replace(" ", "%", $HTTP_POST_VARS[revistarec]); 
		$alterrevrec = $_POST['alterrevrec'];
		$pessoalsv = $HTTP_POST_VARS[pessoalsv];
		$punicoes = $HTTP_POST_VARS[punicoes];
		$ocorrencias = $_POST['ocorrencias'];
		$passeipostograd = str_replace(" ", "%", $HTTP_POST_VARS[passeipostograd]);
		$passeinome = $HTTP_POST_VARS[passeinome];
		$postograd = str_replace(" ", "%", $HTTP_POST_VARS[postograd]);
		$guerra = $HTTP_POST_VARS[guerra];
		
		
		//recebendo dados da tabela sv 
		
		
		$funcaosv = str_replace(" ", "%", $HTTP_POST_VARS[funcaosv]);
		$postogradsv= str_replace(" ", "%", $HTTP_POST_VARS[postogradsv]);
		$nomesv=$_POST['nomesv'];
		
				
		//recebendo dados da tabela punições
		$postogradpun= str_replace(" ", "%", $HTTP_POST_VARS[postogradpun]);
		$numeropun=$_POST['numeropun'];
		$guerrapun=$_POST['guerrapun'];
		$supun= str_replace(" ", "%", $HTTP_POST_VARS[supun]);
		$punicpun=$_POST['punicpun'];
		$ndiaspun=$_POST['ndiaspun'];
		$inipun=$_POST['inipun'];
		$terpun=$_POST['terpun'];
		$bipun=$_POST['bipun'];
		
		//recebendo dados da parte ao fiscal administrativo (variáveis que começam com "fa")
		$famatcarga = $_POST['famatcarga'];
		$fadependencias = $_POST['fadependencias'];
		$fatelalarmes = $_POST['fatelalarmes'];
		$faenergiaconsumo = $HTTP_POST_VARS[faenergiaconsumo];
		$faenergiademanda = $HTTP_POST_VARS[faenergiademanda];
		$faclaviculario = $_POST['faclaviculario'];
		$faabastecimento = str_replace(" ", "%", $HTTP_POST_VARS[faabastecimento]);
		$favtrton = str_replace(" ", "%", $HTTP_POST_VARS[favtrton]);
		$favtreb = $HTTP_POST_VARS[favtreb];
		$favtrodsaida = $HTTP_POST_VARS[favtrodsaida];
		$favtrodchegada = $HTTP_POST_VARS[favtrodchegada];
		$favtrdiferenca = $HTTP_POST_VARS[favtrdiferenca];
		$favtrobs = $_POST['favtrobs'];
		$fapocoartesiano = $_POST['fapocoartesiano'];
		$faluzemergencia = $_POST['faluzemergencia'];
		$faransobras = $HTTP_POST_VARS[faransobras];
		$faranresiduos = $HTTP_POST_VARS[faranresiduos];
		$faranarranchamento = $_POST['faranarranchamento'];
		$farangeneros = $_POST['farangeneros'];
		$famunicao = $_POST['famunicao'];
		
		//formatando data
		$datainicio = "".$HTTP_POST_VARS['anoinicio']."-".$_POST['mesinicio']."-".$_POST['diainicio']."";
		$datatermino = "".$HTTP_POST_VARS['anotermino']."-".$_POST['mestermino']."-".$_POST['diatermino']."";
		
		//recebendo e tratando a tabela sv, tira os índices e as linhas deletadas e realoca em uma nova variável com o índice em ordem
		$i=1;
		$indice=1;
		for ($i==1; $i<=$totalssv; $i++)
				{
					if($funcaosv[$i] == "")
					{
					}
					else
					{
					$funcaosvindice[$indice] = $funcaosv[$i];
					$postogradsvindice[$indice] = $postogradsv[$i];
					$nomesvindice[$indice] = $nomesv[$i];
					$indice++;
					}
				}
		
						//preparar array para inserir no BD com a função implode que junta o array em uma string separando os elementos por vírgula
						$funcaosvbanco = implode(",", $funcaosvindice);
						$postogradsvbanco = implode(",", $postogradsvindice);
						$nomesvbanco = implode(",", $nomesvindice);
		
		//recebendo e tratando a tabela pun, tira os índices e as linhas deletadas e realoca em uma nova variável com o índice em ordem
		if ($postogradpun !=""){//verificando se houve punição
		$i=1;
		$indice=1;
		for ($i==1; $i<=$totalspun; $i++)
				{
					if($postogradpun[$i] == "")
					{
					}
					else
					{
					$postogradpunindice[$indice] = $postogradpun[$i];
					$numeropunindice[$indice] = $numeropun[$i];
					$guerrapunindice[$indice] = $guerrapun[$i];
					$supunindice[$indice] = $supun[$i];
					$punicpunindice[$indice] = $punicpun[$i];
					$ndiaspunindice[$indice] = $ndiaspun[$i];
					$inipunindice[$indice] = $inipun[$i];
					$terpunindice[$indice] = $terpun[$i];
					$bipunindice[$indice] = $bipun[$i];
					$indice++;
					}
				}
			//preparar array para inserir no BD com a função implode que junta o array em uma string separando os elementos por vírgula
			$postogradpunbanco = implode(",", $postogradpunindice);
			$numeropunbanco = implode(",", $numeropunindice);
			$guerrapunbanco = implode(",", $guerrapunindice);
			$supunbanco = implode(",", $supunindice);
			$punicpunbanco = implode(",", $punicpunindice);
			$ndiaspunbanco = implode(",", $ndiaspunindice);
			$inipunbanco = implode(",", $inipunindice);
			$terpunbanco = implode(",", $terpunindice);
			$bipunbanco = implode(",", $bipunindice);
		}
		
		
		//inserindo no banco		
				
		$result = mysql_query('insert into livro (idusuario,diainicio,mesinicio,anoinicio,diatermino,mestermino,anotermino,ofdiaposto,ofdianome,recebipostograd,recebinome,parada,alterparada,correspondencia,apresmil,rondaint,rondaext,revistarec,alterrevrec,pessoalsv,punicoes,ocorrencias,passeipostograd,passeinome,adjgrad,adjnome,datainicio,datatermino,funcaosv,postogradsv,nomesv,postogradpun,numeropun,guerrapun,supun,punicpun,ndiaspun,inipun,terpun,bipun,totalssv,totalspun,famatcarga,fadependencias,fatelalarmes,faenergiaconsumo,faenergiademanda,faclaviculario,faabastecimento,favtrton,favtreb,favtrodsaida,favtrodchegada,favtrdiferenca,favtrobs,fapocoartesiano,faluzemergencia,faransobras,faranresiduos,faranarranchamento,farangeneros,famunicao) values("'.$idusuario.'","'.$diainicio.'","'.$mesinicio.'","'.$anoinicio.'","'.$diatermino.'","'.$mestermino.'","'.$anotermino.'","'.$ofdiaposto.'","'.$ofdianome.'","'.$recebipostograd.'","'.$recebinome.'","'.$parada.'","'.$alterparada.'","'.$correspondencia.'","'.$apresmil.'","'.$rondaint.'","'.$rondaext.'","'.$revistarec.'","'.$alterrevrec.'","'.$pessoalsv.'","'.$punicoes.'","'.$ocorrencias.'","'.$passeipostograd.'","'.$passeinome.'","'.$postograd.'","'.$guerra.'","'.$datainicio.'","'.$datatermino.'","'.$funcaosvbanco.'","'.$postogradsvbanco.'","'.$nomesvbanco.'","'.$postogradpunbanco.'","'.$numeropunbanco.'","'.$guerrapunbanco.'","'.$supunbanco.'","'.$punicpunbanco.'","'.$ndiaspunbanco.'","'.$inipunbanco.'","'.$terpunbanco.'","'.$bipunbanco.'","'.$totalssv.'","'.$totalspun.'","'.$famatcarga.'","'.$fadependencias.'","'.$fatelalarmes.'","'.$faenergiaconsumo.'","'.$faenergiademanda.'","'.$faclaviculario.'","'.$faabastecimento.'","'.$favtrton.'","'.$favtreb.'","'.$favtrodsaida.'","'.$favtrodchegada.'","'.$favtrdiferenca.'","'.$favtrobs.'","'.$fapocoartesiano.'","'.$faluzemergencia.'","'.$faransobras.'","'.$faranresiduos.'","'.$faranarranchamento.'","'.$farangeneros.'","'.$famunicao.'");',$conexaolivro);
          
	   
	   
		if ($result)
			{
			echo '<center>Livro Registrado com Sucesso.<br>';
			
			//para testar as variáveis tire o comentário
				//echo $idusuario;echo 'idusuario<br>';
				//echo $diainicio;echo 'diainicio<br>';
				////echo $mesinicio;echo 'mesinicio<br>';
				//echo $anoinicio;echo 'anoinicio<br>';
				//echo $diatermino;echo 'diatermino<br>';
				//echo $mestermino;echo 'mestermino<br>';
				//echo $anotermino;	echo 'anotermino<br>';
				//echo $recebipostograd; echo 'recebipostograd<br>';
				//echo $recebinome;echo 'recebinome<br>';
				//echo $parada; echo 'parada<br>';
				//echo $alterparada;echo 'alterparada<br>';
				//echo $correspondencia;echo 'correspondencia<br>';
				//echo $apresmil;echo 'apresmil<br>';
				//echo $rondaint;echo 'rondaint<br>';
				//echo $rondaext;echo 'rondaex<br>';
				//echo $revistarec; echo 'revistarec<br>';
				//echo $alterrevrec;echo 'alterrevrec<br>';
				//echo $pessoalsv;echo 'pessoalsv<br>';
				//echo $punicoes;echo 'punicoes<br>';
				//echo $ocorrencias;echo 'ocorrencias<br>';
				//echo $passeipostograd;echo 'passeipostograd<br>';
				//echo $passeinome;echo 'passeinome<br>';
				//echo $postograd;echo 'adjgrad;<br>';
				//echo $guerra;echo 'adjnome<br>';
				//echo $datainicio;echo 'datainicio<br>';
				//echo $datatermino;echo 'datatermino<br>';
				//variáveis da tabela sv
				//print_r($funcaosvindice);echo 'datatermino<br>';
				//print_r($postogradsvindice);echo 'datatermino<br>';
				//print_r($nomesvindice);echo 'datatermino<br>';
				//echo $funcaosvindice['1']; echo'teste do array';
				//variáveis da tabela punicoues
				//print_r($postogradpunindice);echo 'postogradpunindice<br>';
				//print_r($postogradpunbanco);echo 'postogradpunbanco<br>';
				//print_r($numeropunindice);echo 'numeropunindice<br>';
				
				//print_r($guerrapunindice);echo 'guerrapunindice<br>';
				//print_r($supunindice);echo 'supunindice<br>';
				//print_r($punicpunindice);echo 'punicpunindice<br>';
				//print_r($ndiaspunindice);echo 'ndiaspunindice<br>';
				//print_r($inipunindice);echo 'inipunindice<br>';
				//print_r($terpunindice);echo 'terpunindice<br>';
				//print_r($bipunindice);echo 'bipunindice<br>';
			}
		else
			{
				echo '<center> Erro ao Registrar Livro!<br><center>Verifique os dados fornecidos ou contate o administrador!';
				echo '<br>';
				
				//para testar as variáveis tire o comentário
				echo "erro encontrado:  ";
				echo mysql_errno() . ": " . mysql_error(). "\n";
				//echo $idusuario;echo 'idusuario<br>';
				//echo $diainicio;echo 'diainicio<br>';
				//echo $mesinicio;echo 'mesinicio<br>';
				//echo $anoinicio;echo 'anoinicio<br>';
				//echo $diatermino;echo 'diatermino<br>';
				//echo $mestermino;echo 'mestermino<br>';
				//echo $anotermino;	echo 'anotermino<br>';
				//echo $recebipostograd; echo 'recebipostograd<br>';
				//echo $recebinome;echo 'recebinome<br>';
				//echo $parada; echo 'parada<br>';
				//echo $alterparada;echo 'alterparada<br>';
				//echo $correspondencia;echo 'correspondencia<br>';
				//echo $apresmil;echo 'apresmil<br>';
				//echo $rondaint;echo 'rondaint<br>';
				//echo $rondaext;echo 'rondaex<br>';
				//echo $revistarec; echo 'revistarec<br>';
				//echo $alterrevrec;echo 'alterrevrec<br>';
				//echo $pessoalsv;echo 'pessoalsv<br>';
				//echo $punicoes;echo 'punicoes<br>';
				//echo $ocorrencias;echo 'ocorrencias<br>';
				//echo $passeipostograd;echo 'passeipostograd<br>';
				//echo $passeinome;echo 'passeinome<br>';
				//echo $postograd;echo 'adjgrad;<br>';
				//echo $guerra;echo 'adjnome<br>';
				//echo $datainicio;echo 'datainicio<br>';
				//echo $datatermino;echo 'datatermino<br>';
				//variáveis da tabela sv
				//print_r($funcaosvindice);echo 'funcaosvindice<br>';
				//print_r($funcaosvbanco);echo 'funcaosvbanco<br>';
				//print_r($postogradsvindice);echo 'postogradsvindice<br>';
				//print_r($nomesvindice);echo 'nomesvindice<br>';
				
				//variáveis da tabela punicoues
				//print_r($postogradpunindice);echo 'postogradpunindice<br>';
				//print_r($numeropunindice);echo 'numeropunindice<br>';
				//print_r($guerrapunindice);echo 'guerrapunindice<br>';
				//print_r($supunindice);echo 'supunindice<br>';
				//print_r($punicpunindice);echo 'punicpunindice<br>';
				//print_r($ndiaspunindice);echo 'ndiaspunindice<br>';
				//print_r($inipunindice);echo 'inipunindice<br>';
				//print_r($terpunindice);echo 'terpunindice<br>';
				//print_r($bipunindice);echo 'bipunindice<br>';
				
				
			}
	
		}
			else
				{
					echo '<center>Usuario não autorizado!';
				}
		}
else
{
	echo '<center>Usuario não autorizado!';
}
?>

</body>
</body>
</html>
