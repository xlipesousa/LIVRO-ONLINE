<?
session_start();
include "base.php";
if (isset($_SESSION['nivel'])) 
{
 		$logado = $_SESSION['nivel'];
  		if ($logado == '1')
		{
			
		if (! isset($_GET['idusuario']))
		{
			echo "<script>alert('Usuario n�o selecionado!'); history.back(-1);</script>";
			exit;
		}
	
		$idusuario = $_GET['idusuario'];
		$idusuario = trim(addslashes($idusuario));
	
		//verificando se o livro existe
		$result = mysql_query("SELECT id FROM usuarios WHERE id LIKE '%".$idusuario."%';",$conexaolivro);
		$Quantos = mysql_num_rows($result);
		if($Quantos < 1)
		{
			echo "<script>alert('Usuario N�o Encontrado!'); location.href = 'excluirusuarios.php';</script>";
			exit;
		} 
		else
		{		
		
				
				$update = "UPDATE usuarios SET nivel = '7' WHERE id = '$idusuario'";
				mysql_query($update, $conexaolivro);
				echo "<script>alert('Usu�rio Deletado Com Sucesso!'); location.href = 'excluirusuarios.php';</script>";
				exit;
		}
		
		
		}
		else
		{
		echo '<center>Usuario n�o autorizado!';
		}
}
else
{
	echo '<center>Usuario n�o autorizado!';
}	
	?>
</body>
</body>
</html>
