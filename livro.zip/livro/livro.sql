-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: 18/02/2020 às 19:02:14
-- Versão do Servidor: 5.5.41-0+wheezy1
-- Versão do PHP: 5.3.3-7+squeeze19

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `livro2`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `livro`
--

CREATE TABLE IF NOT EXISTS `livro` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `idusuario` varchar(5) NOT NULL,
  `datainicio` date DEFAULT NULL,
  `datatermino` date DEFAULT NULL,
  `diainicio` char(2) NOT NULL,
  `mesinicio` char(2) NOT NULL,
  `anoinicio` char(4) NOT NULL,
  `diatermino` char(2) NOT NULL,
  `mestermino` char(2) NOT NULL,
  `anotermino` char(4) NOT NULL,
  `ofdiaposto` varchar(8) NOT NULL,
  `ofdianome` varchar(60) NOT NULL,
  `recebipostograd` varchar(8) NOT NULL,
  `recebinome` varchar(80) NOT NULL,
  `parada` varchar(80) NOT NULL,
  `alterparada` varchar(2600) DEFAULT NULL,
  `correspondencia` varchar(2600) DEFAULT NULL,
  `apresmil` varchar(2600) DEFAULT NULL,
  `rondaint` varchar(2600) DEFAULT NULL,
  `rondaext` varchar(2600) DEFAULT NULL,
  `revistarec` varchar(600) DEFAULT NULL,
  `alterrevrec` varchar(2600) DEFAULT NULL,
  `pessoalsv` varchar(1200) DEFAULT NULL,
  `punicoes` varchar(2400) DEFAULT NULL,
  `ocorrencias` varchar(20600) DEFAULT NULL,
  `passeipostograd` varchar(8) NOT NULL,
  `passeinome` varchar(80) NOT NULL,
  `adjgrad` varchar(8) NOT NULL,
  `adjnome` varchar(80) NOT NULL,
  `despachado` varchar(1) NOT NULL DEFAULT 'n',
  `funcaosv` text,
  `postogradsv` varchar(200) DEFAULT NULL,
  `nomesv` varchar(1200) DEFAULT NULL,
  `postogradpun` varchar(200) DEFAULT NULL,
  `numeropun` varchar(300) DEFAULT NULL,
  `guerrapun` varchar(1500) DEFAULT NULL,
  `supun` varchar(100) DEFAULT NULL,
  `punicpun` varchar(100) DEFAULT NULL,
  `ndiaspun` varchar(300) DEFAULT NULL,
  `inipun` varchar(500) DEFAULT NULL,
  `terpun` varchar(500) DEFAULT NULL,
  `bipun` varchar(300) DEFAULT NULL,
  `totalssv` varchar(6) DEFAULT NULL,
  `totalspun` varchar(6) DEFAULT NULL,
  `s1despacho` varchar(600) DEFAULT NULL,
  `s2despacho` varchar(600) DEFAULT NULL,
  `s3despacho` varchar(600) DEFAULT NULL,
  `s4despacho` varchar(600) DEFAULT NULL,
  `s1check` varchar(1) NOT NULL DEFAULT 's',
  `s2check` varchar(1) NOT NULL DEFAULT 's',
  `s3check` varchar(1) NOT NULL DEFAULT 's',
  `s4check` varchar(1) NOT NULL DEFAULT 's',
  `bo1despacho` varchar(600) DEFAULT NULL,
  `bo2despacho` varchar(600) DEFAULT NULL,
  `bcdespacho` varchar(600) DEFAULT NULL,
  `aaedespacho` varchar(600) DEFAULT NULL,
  `bo1check` varchar(2) NOT NULL DEFAULT 's',
  `bo2check` varchar(2) NOT NULL DEFAULT 's',
  `bccheck` varchar(2) NOT NULL DEFAULT 's',
  `aaecheck` varchar(2) NOT NULL DEFAULT 's',
  `fiscaldespacho` varchar(600) DEFAULT NULL,
  `fiscalcheck` varchar(1) NOT NULL DEFAULT 's',
  `famatcarga` varchar(1200) DEFAULT NULL,
  `fadependencias` varchar(1200) DEFAULT NULL,
  `fatelalarmes` varchar(1200) DEFAULT NULL,
  `faenergiaconsumo` varchar(10) DEFAULT NULL,
  `faenergiademanda` varchar(10) DEFAULT NULL,
  `faclaviculario` varchar(1200) DEFAULT NULL,
  `faabastecimento` varchar(25) DEFAULT NULL,
  `favtrton` varchar(5) DEFAULT NULL,
  `favtreb` varchar(30) DEFAULT NULL,
  `favtrodsaida` varchar(25) DEFAULT NULL,
  `favtrodchegada` varchar(25) DEFAULT NULL,
  `favtrdiferenca` varchar(25) DEFAULT NULL,
  `favtrobs` varchar(1200) DEFAULT NULL,
  `fapocoartesiano` varchar(1200) DEFAULT NULL,
  `faluzemergencia` varchar(1200) DEFAULT NULL,
  `faransobras` varchar(5) DEFAULT NULL,
  `faranresiduos` varchar(5) DEFAULT NULL,
  `faranarranchamento` varchar(1200) DEFAULT NULL,
  `farangeneros` varchar(1200) DEFAULT NULL,
  `famunicao` varchar(1200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `postograd` varchar(8) NOT NULL,
  `nome` varchar(60) NOT NULL,
  `guerra` varchar(80) NOT NULL,
  `idt` varchar(30) NOT NULL,
  `su` char(3) NOT NULL,
  `usuario` char(30) NOT NULL,
  `senha` varchar(30) NOT NULL,
  `nivel` varchar(2) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `usuario` (`usuario`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `postograd`, `nome`, `guerra`, `idt`, `su`, `usuario`, `senha`, `nivel`) VALUES
(1, '2sgt', 'Administrador', 'Administrador', 'xxxxxxxxxxx', 'bc', 'admin', 'admin', '1');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
