<?
session_start();
include "base.php";
if (isset($_SESSION['nivel'])) 
{
 	$logado = $_SESSION['nivel'];
  	if ($logado)
	{		
		echo'<html>
		<head>
		<title>Alterar Usuario</title>
		</head>
		<body>';
		
		if (! isset($_GET['idusuario']))
		{
			echo "<script>alert('Usuario n�o selecionado!'); history.back(-1);</script>";
			exit;
		}
		$idusuario = $_GET['idusuario'];
		$idusuario = trim(addslashes($idusuario));
		

		
		//inserindo no banco		
		$result = mysql_query("UPDATE usuarios SET senha='123456' WHERE id='".$idusuario."';",$conexaolivro);
       
		if ($result)
			{
			echo '<center>Usu�rio Alterado com Sucesso! <BR><BR><center>NOVA SENHA: 123456';
			}
		else
			{
				echo '<center> Erro ao alterar as usu�rio! contate o administrador!';
			}
	
		}
			else
				{
					echo '<center>Usuario n�o autorizado!';
				}
		}
else
{
	echo '<center>Usuario n�o autorizado!';
}
?>

</body>
</body>
</html>
