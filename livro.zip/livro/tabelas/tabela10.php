<html>

<body>

<?php
foreach($_POST["nome"] as $nome){
echo $nome."<br />";
?>
</body>
</html>
