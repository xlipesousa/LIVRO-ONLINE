// JavaScript Document
<html>
<HEAD>

<SCRIPT LANGUAGE="JavaScript">
function addRow(id){
var tbody = document.getElementById
(id).getElementsByTagName("TBODY")[0];
var row = document.createElement("TR")
//cria a primeiro td
var td1 = document.createElement("TD")
td1.appendChild(document.createTextNode("Nome"))


//cria o segundo td
var td2 = document.createElement("TD")
td2.appendChild (document.createTextNode("Aqui deve ser um input para o usuario digitar o nome dele"))




row.appendChild(td1);
row.appendChild(td2);
tbody.appendChild(row);
}

</script>

</HEAD>


<BODY>

<a href="javascript:addRow('Tabela')">Adiciona linhas</a>

<table id="Tabela" cellspacing="0" border="1">
<tbody>
<tr>
<td>Linha coluna</td><td>Linha Coluna</td>
</tr>
</tbody>
</table>