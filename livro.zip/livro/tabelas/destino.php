<html>

<body>

<?php

$funcao1=$_POST['funcao'][1];
$funcao2=$_POST['funcao'][2];
$funcao3=$_POST['funcao'][3];

$postograd0=$_POST['postograd'][0];
$postograd1=$_POST['postograd'][1];
$postograd2=$_POST['postograd'][2];

$nome0=$_POST['nome'][0];
$nome1=$_POST['nome'][1];
$nome2=$_POST['nome'][2];


echo $funcao1."&nbsp;funcao1<br />";
echo $funcao2."&nbsp;funcao2<br />";
echo $funcao3."&nbsp;funcao3<br />";

echo "<br />";
echo "<br />";
echo "<br />";

echo $postograd0."&nbsp;postograd0<br />";
echo $postograd1."&nbsp;postograd1<br />";
echo $postograd2."&nbsp;postograd2<br />";

echo "<br />";
echo "<br />";
echo "<br />";

echo $nome0."&nbsp;nome0<br />";
echo $nome1."&nbsp;nome1<br />";
echo $nome2."&nbsp;nome2<br />";

echo "<br />";
echo "<br />";
echo "<br />";



echo "<br />";
echo "<br />";
echo "<br />";

$funcaovetor=$_POST['funcao'];
$postogradvetor=$_POST['postograd'];
$nomevetor=$_POST['nome'];

echo $funcaovetor[0]."&nbsp;funcaovetor0<br />";
echo $funcaovetor[1]."&nbsp;funcaovetor1<br />";
echo $funcaovetor[2]."&nbsp;funcaovetor2<br />";

echo "<br />";
echo "<br />";
echo "<br />";

echo $postogradvetor[0]."&nbsp;postogradvetor0<br />";
echo $postogradvetor[1]."&nbsp;postogradvetor1<br />";
echo $postogradvetor[2]."&nbsp;postogradvetor2<br />";

echo "<br />";
echo "<br />";
echo "<br />";


echo $nomevetor[0]."&nbsp;nomevetor0<br />";
echo $nomevetor[1]."&nbsp;nomevetor1<br />";
echo $nomevetor[2]."&nbsp;nomevetor2<br />";




?>
</body>
</html>
