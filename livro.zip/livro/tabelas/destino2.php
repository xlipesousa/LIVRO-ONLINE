<html>

<body>

<?php


		//recebendo o total de linhas da tabela sv incluindo as que foram deletadas
		$totalssv=$_POST['totalssv'];

		//recebendo dados da tabela sv 
		$funcaosv= str_replace(" ", "%", $HTTP_POST_VARS[funcaosv]);
		$postogradsv= str_replace(" ", "%", $HTTP_POST_VARS[postogradsv]);
		$nomesv=$_POST['nomesv'];
		
		//recebendo dados da tabela puni��es
		$postogradpun= str_replace(" ", "%", $HTTP_POST_VARS[postogradpun]);
		$numeropun=$_POST['numeropun'];
		$guerrapun=$_POST['guerrapun'];
		$supun= str_replace(" ", "%", $HTTP_POST_VARS[supun]);
		$punicpun=$_POST['punicpun'];
		$ndiaspun=$_POST['ndiaspun'];
		$inipun=$_POST['inipun'];
		$terpun=$_POST['terpun'];
		$bipun=$_POST['bipun'];
		
		
		
       echo' teste totals';
		echo "<br />";
		echo $_POST['totalssv'];
		echo "<br />";
		echo "<br />";
		
		
		$i=1;
		$indice=1;
		for ($i==1; $i<=$totalssv; $i++)
				{
					if($funcaosv[$i] == "")
					{}
					else
					{
					$funcao2[$indice] = $funcaosv[$i];
					$indice++;
					echo $funcaosv[$i];
					echo " funcaosv ";
					echo $i;
					echo "<br>";
					}
				}
		
echo "<br>imprime o vetor funcao2<br>";
print_r($funcao2);

?>
</body>
</html>
