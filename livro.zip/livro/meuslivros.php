<?
include "base.php";
session_start("usuarios");
$logado = $_SESSION['nivel'];
if ($logado == '2')
		{
		$idusuario = $_SESSION['id'];
		?>
		<html>
			<head>
			<title>Consultar Meus livros</title>
			<script>function checar(pagina,texto) { if (confirm("DSEJA REALMENTE DELETAR ESTE LIVRO?")==true) { window.location=pagina; } }</script>
			<script language="JavaScript">
				function mudacelula(){
					var cor = "#FFFF75";
					var elemento = document.getElementById("teste");
					elemento.style.backgroundColor = cor;
				}
			</script>
			</head>

		<body>
		<table width="500" height="97" border="0" cellpadding="0" cellspacing="0">
           <tr> 
               <td valign="top"><div align="center"><img src="../livro/imagens/livro.jpg"></div></td>
  			</tr>
  			<tr> 
   			<td height="19"> 
				  <?php
				$sql = "SELECT id, diainicio, mesinicio, anoinicio, ofdiaposto, ofdianome,despachado FROM livro WHERE idusuario='".$idusuario."' ORDER BY id DESC";
				$qry = mysql_query($sql, $conexaolivro);
				$totalreg = mysql_num_rows($qry);
				$i = 0; 
				?>
      			<div align="center"> 
                        <table width="540" border="0" cellpadding="0" cellspacing="0" bgcolor="#999999">
							<tr>
								<td width="95"><center>Cod Livro
								</td>
								<td width="120"><center>Data SV
								</td>
								<td width="80"><center>Of Dia
								</td>
								<td width="80"><center>Despachado
								</td>
								<td width="80"><center>Alterar
								</td>
								<td width="80"><center>Excluir
								</td>
								<td width="80"><center>Ler
								</td>
							</tr>
							<?php
							if ($totalreg < 1){
							echo "<tr><td width=\"440\"><div align=\"center\"><font class=\"font1\"><i><br><br>Nenhum <u>Livro</u> Encontrado!</i></font></div></td></tr>";
							} else {
							
					while ($reg = mysql_fetch_array($qry, MYSQL_ASSOC)){
							$idlivro = mysql_result($qry,$i,id);
							$diainicio = mysql_result($qry,$i,diainicio);
							$mesinicio = mysql_result($qry,$i,mesinicio);
							$anoinicio = mysql_result($qry,$i,anoinicio);
							$ofdiaposto = mysql_result($qry,$i,ofdiaposto);
							$ofdianome = mysql_result($qry,$i,ofdianome);
							$despachado = mysql_result($qry,$i,despachado);
							
							//corrigindo o posto do of dia
							switch ($ofdiaposto){
								case '1ten':
      								$ofdiaposto='1� Ten';
     								break;
								case '2ten':
      								$ofdiaposto='2� Ten';
     								break;
								case 'asp':
      								$ofdiaposto='Asp';
     								break;
									}
									
							//corrigindo despacho
							switch ($despachado){
								case 's':
      								$despachado='Sim';
     								break;
								default :
      								$despachado='N�o';
     								break;
									}		
					?>
						   <tr id="teste" onMouseOver="this.style.backgroundColor='#C1FFC1'" onMouseOut="this.style.backgroundColor='<?=($i % 2 == 0 ? "#F7F7F7" : "#E6E6E6")?>'" bgcolor="<?=($i % 2 == 0 ? "#F7F7F7" : "#E6E6E6")?>"> 
						   
						   
							<td  height="19"><font class="font1"><center><?php echo $idlivro; ?></font></td>
							
							
							<td  height="19"><font class="font1"><center><?php echo $diainicio; echo'/';echo $mesinicio; echo'/'; echo $anoinicio; ?></font></td>
							
							
							<td width="80" height="19"><font class="font1"><center><?php echo $ofdiaposto; echo'&nbsp;'; echo $ofdianome; ?></font></td>
							
							
							<td width="120" height="19"><font class="font1"><center><?php echo $despachado; ?></font></td>
							
							
							
							<!-- verifica se o livro j� foi despachado, caso sim o mesmo n�o poe ser excluido-->
							<? if ($despachado == 'Sim')
							{
							
							echo "<td width='36'><div align='center'><img src='../livro/imagens/naoalterar.png' border='0' alt='Alterar'></div></td>";
							
							echo "<td width='36'><div align='center'><img src='../livro/imagens/naoexcluir.png' border='0' alt='Ecluir'></div></td>";
							}
							else
							{
							echo "<td width='36'><div align='center'><a href='../livro/alterarlivro.php?idlivro="; echo $idlivro; echo "'  ><img src='../livro/imagens/alterar.png' border='0' alt='Alterar' ></a></div></td>";

							
							echo "<td width='36'><div align='center'><a href="; echo'"'; echo"javascript:checar('excluirlivro.php?idlivro="; echo $idlivro; echo"');"; echo'"'; echo"><img src='../livro/imagens/excluir.png' border='0' alt='Deletar'></a></div></td>";
							}
							?>			
							
							<td width="36"><div align="center"><a target ='_blank' href="../livro/lerlivro.php?idlivro=<?php echo $idlivro; ?>"><img src="../livro/imagens/ler.png" border="0" alt="Ler"></a></div></td>
						  </tr>
						  <?php
					$i++;
						}
					}
					?>
						</table><p></p>
      </div></td>
  </tr>
</table>
			
		</body>
		</html>
		
		
		
		
	
<?
		}
	else
	{echo '
	<htm>
<head>
<title>Meus Livros</title>
</head>
<body>
	<center>Usuario n�o autorizado!
	
	</body>
</html>';

	}
	?>