<?
session_start();
include "base.php";
if (isset($_SESSION['nivel'])) 
{
 	$logado = $_SESSION['nivel'];
  	if ($logado == '2')
	{
	
	$idlivro = $_GET['idlivro'];
	//selecionando dados do usuario
	$result = mysql_query("SELECT * FROM livro WHERE id LIKE '%".$idlivro."%';",$conexaolivro);
	$Quantos = mysql_num_rows($result);
	if($Quantos > 0)
	{

	//iniciando vari�veis
			$idusuario = mysql_result($result,0,idusuario);
			$diainicio = mysql_result($result,0,diainicio);
			$mesinicio = mysql_result($result,0,mesinicio);;
			$anoinicio = mysql_result($result,0,anoinicio);
			$diatermino = mysql_result($result,0,diatermino);
			$mestermino = mysql_result($result,0,mestermino);
			$anotermino = mysql_result($result,0,anotermino);	
			$ofdiaposto = mysql_result($result,0,ofdiaposto); 
			$ofdianome = mysql_result($result,0,ofdianome);
			$recebipostograd = mysql_result($result,0,recebipostograd); 
			$recebinome = mysql_result($result,0,recebinome);
			$parada = mysql_result($result,0,parada); 
			$alterparada = mysql_result($result,0,alterparada);
			$correspondencia = mysql_result($result,0,correspondencia);
			$apresmil = mysql_result($result,0,apresmil);
			$rondaint = mysql_result($result,0,rondaint);
			$rondaext = mysql_result($result,0,rondaext);
			$revistarec = mysql_result($result,0,revistarec);; 
			$alterrevrec = mysql_result($result,0,alterrevrec);
			$pessoalsv = mysql_result($result,0,pessoalsv);
			$punicoes = mysql_result($result,0,punicoes);
			$ocorrencias = mysql_result($result,0,ocorrencias);
			$passeipostograd = mysql_result($result,0,passeipostograd);
			$passeinome = mysql_result($result,0,passeinome);
			$adjgrad = mysql_result($result,0,adjgrad);
			$adjnome = mysql_result($result,0,adjnome);
			$totalssv = mysql_result($result,0,totalssv);
			$totalspun = mysql_result($result,0,totalspun);
			$famatcarga = mysql_result($result,0,famatcarga);
			$fadependencias = mysql_result($result,0,fadependencias);
			$fatelalarmes = mysql_result($result,0,fatelalarmes);
			$faenergiaconsumo = mysql_result($result,0,faenergiaconsumo);
			$faenergiademanda = mysql_result($result,0,faenergiademanda);
			$faclaviculario = mysql_result($result,0,faclaviculario);
			$faabastecimento = mysql_result($result,0,faabastecimento);
			$favtrton = mysql_result($result,0,favtrton);
			$favtreb = mysql_result($result,0,favtreb);
			$favtrodsaida = mysql_result($result,0,favtrodsaida);
			$favtrodchegada = mysql_result($result,0,favtrodchegada);
			$favtrdiferenca = mysql_result($result,0,favtrdiferenca);
			$favtrobs = mysql_result($result,0,favtrobs);
			$fapocoartesiano = mysql_result($result,0,fapocoartesiano);
			$faluzemergencia = mysql_result($result,0,faluzemergencia);
			$faransobras = mysql_result($result,0,faransobras);
			$faranresiduos = mysql_result($result,0,faranresiduos);
			$faranarranchamento = mysql_result($result,0,faranarranchamento);
			$farangeneros = mysql_result($result,0,farangeneros);
			$famunicao = mysql_result($result,0,famunicao);
			
			//recebendo dados da tabela sv 
			$funcaosv = mysql_result($result,0,funcaosv);
			$postogradsv = mysql_result($result,0,postogradsv);
			$nomesv = mysql_result($result,0,nomesv);
			
			//trasnformando a string novamente em array
	  		$funcaosv = explode(",", $funcaosv);
			$postogradsv = explode(",", $postogradsv);
			$nomesv = explode(",", $nomesv);
							
			//recebendo dados da tabela puni��es
			$postogradpun = mysql_result($result,0,postogradpun);
			$numeropun = mysql_result($result,0,numeropun);
			$guerrapun = mysql_result($result,0,guerrapun);
			$supun = mysql_result($result,0,supun);
			$punicpun = mysql_result($result,0,punicpun);
			$ndiaspun = mysql_result($result,0,ndiaspun);
			$inipun = mysql_result($result,0,inipun);
			$terpun = mysql_result($result,0,terpun);
			$bipun = mysql_result($result,0,bipun);
			
			//trasnformando a string novamente em array
			if ($postogradpun != ""){
	  		$postogradpun = explode(",", $postogradpun);
			$numeropun = explode(",", $numeropun);
			$guerrapun = explode(",", $guerrapun);
			$supun = explode(",", $supun);
			$punicpun = explode(",", $punicpun);
			$ndiaspun = explode(",", $ndiaspun);
			$inipun = explode(",", $inipun);
			$terpun = explode(",", $terpun);
			$bipun = explode(",", $bipun);
			}		
			$datainicio = mysql_result($result,0,datainicio);
			$datatermino = mysql_result($result,0,datatermino);
			
			//identificando o adj
			$resultadj = mysql_query("SELECT postograd, guerra FROM usuarios WHERE id ='".$idusuario."';",$conexaolivro);
			$postograd = mysql_result($resultadj,0,postograd);
			$guerra = mysql_result($resultadj,0,guerra);
	
	// Fun��o para transformar strings em Mai�scula ou Min�scula com acentos
			// $palavra = a string propriamente dita
			// $tp = tipo da convers�o: 1 para mai�sculas e 0 para min�sculas
			function convertem($term, $tp) {
				if ($tp == "1") $palavra = strtr(strtoupper($term),"������������������������������","������������������������������");
				elseif ($tp == "0") $palavra = strtr(strtolower($term),"������������������������������","������������������������������");
				return $palavra;
			} 
	
echo '

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Livro</title>';

?>
<script LANGUAGE="JavaScript">
	//inicializando a vari�vel ara come�ar a incluir campos a contar da pr�xima posi��o a ser inserida 
    var totalssv = <? echo $totalssv; ?>;
	
	function deleteRowSv(i){
	
	totalssv--
	
    document.getElementById('tabelasv').deleteRow(i)
	
	//alert(totalssv + " " +totalspun);
	
    }
    function adicionasv(){
    totalssv++
	
	//aqui a input hidden de id="totalssv" que est� no fim do form recebe o valor da variavel totalssv

	//cria um objeto de refer�ncia � tag input hidden
	var objetoDados = document.getElementById("totalssv");
	//altera o atributo value desta tag
	objetoDados.value = totalssv;
	
        tbl = document.getElementById("tabelasv")

        var novaLinha = tbl.insertRow(-1);
        var novaCelula;

        if(totalssv%2==0) cl = "#b0b0b0";
        else cl = "#dadada";

        novaCelula = novaLinha.insertCell(0);

        novaCelula.style.backgroundColor = cl

        novaCelula.innerHTML = "<select name='funcaosv["+totalssv+"]'><option value=''>Selecione</option><option value='orc'>ORC</option><option value='ofdia'>Of Dia</option><option value='adjofdia'>Adj Of Dia</option><option value='cmtgda'>Cmt Gda</option><option value='cbgdafte'>Cb Gda Fte</option><option value='cbgdafun'>Cb Gda Fun</option><option value='motdia'>Mot Dia</option><option value='sgtdran'>Sgt D Ran</option><option value='clarin'>Clarin</option><option value='comsoc'>Com Soc</option><option value='medsbv'>Med SBV</option><option value='dentsbv'>Dent SBV</option><option value='atddia'>Atd Dia</option><option value='eltdia'>Elt Dia</option><option value='teldia'>Tel Dia</option><option value='permcanil'>Perm Canil</option><option value='revdia'>Rev Dia</option></select>";



        novaCelula = novaLinha.insertCell(1);
        novaCelula.align = "left";
        novaCelula.style.backgroundColor = cl;
        novaCelula.innerHTML = "<select name='postogradsv["+totalssv+"]'><option value=''>Selecione</option><option value='cap'>Cap</option><option value='1ten'>1� Ten</option><option value='2ten'>2� Ten</option><option value='asp'>Asp</option><option value='1sgt'>1� Sgt</option><option value='2sgt'>2� Sgt</option><option value='3sgt'>3� Sgt</option><option value='t1'>T1</option><option value='cb'>Cb</option><option value='sdnb'>Sd NB</option><option value='sdev'>Sd EV</option></select>";

		novaCelula = novaLinha.insertCell(2);
        novaCelula.align = "left";
        novaCelula.style.backgroundColor = cl;
        novaCelula.innerHTML = "<input type='text' name='nomesv["+totalssv+"]' size='30'>";
		
		novaCelula = novaLinha.insertCell(3);
        novaCelula.align = "left";
        novaCelula.style.backgroundColor = cl;
        novaCelula.innerHTML = "<input type='button' value='Delete' id='deletesv' onclick='deleteRowSv(this.parentNode.parentNode.rowIndex)'>";
		//alert(totalssv + " " +totalspun);
}

		var totalspun = <? echo $totalspun; ?>;
		function deleteRowPun(i){
		
		totalspun--
		
		document.getElementById('tabelapun').deleteRow(i)
		//alert(totalssv + " " +totalspun);
		
		}
		function adicionapun(){
		totalspun++
		
	//aqui a input hidden de id="totalspun" que est� no fim do form recebe o valor da variavel totalspun

	//cria um objeto de refer�ncia � tag input hidden
	var objetoDados = document.getElementById("totalspun");
	//altera o atributo value desta tag
	objetoDados.value = totalspun;
	
			tbl = document.getElementById("tabelapun")
	
			var novaLinha = tbl.insertRow(-1);
			var novaCelula;
	
			if(totalssv%2==0) cl = "#b0b0b0";
			else cl = "#dadada";
	
			novaCelula = novaLinha.insertCell(0);
	
			novaCelula.style.backgroundColor = cl
	
			novaCelula.innerHTML = "<select name='postogradpun["+totalspun+"]'><option value=''>-</option><option value='cap'>Cap</option><option value='1ten'>1� Ten</option><option value='2ten'>2� Ten</option><option value='asp'>Asp</option><option value='st'>ST</option><option value='1sgt'>1� Sgt</option><option value='2sgt'>2� Sgt</option><option value='3sgt'>3� Sgt</option><option value='t1'>T1</option><option value='cb'>Cb</option><option value='sdnb'>Sd NB</option><option value='sdev'>Sd EV</option></select>";
	
			novaCelula = novaLinha.insertCell(1);
			novaCelula.align = "left";
			novaCelula.style.backgroundColor = cl;
			novaCelula.innerHTML = "<input type='text' name='numeropun["+totalspun+"]' size='1'>";
	
			novaCelula = novaLinha.insertCell(2);
			novaCelula.align = "left";
			novaCelula.style.backgroundColor = cl;
			novaCelula.innerHTML = "<input type='text' name='guerrapun["+totalspun+"]' size='10'>";
			
			novaCelula = novaLinha.insertCell(3);
			novaCelula.align = "left";
			novaCelula.style.backgroundColor = cl;
			novaCelula.innerHTML = "<select name='supun["+totalspun+"]'><option value=''>-</option><option value='em'>EM</option><option value='1bo'>1� BO</option><option value='2bo'>2� BO</option><option value='bc'>BC</option><option value='aae'>AAe</option></select>";
			
			novaCelula = novaLinha.insertCell(4);
			novaCelula.align = "left";
			novaCelula.style.backgroundColor = cl;
			novaCelula.innerHTML = "<input type='text' name='punicpun["+totalspun+"]' size='1'>";
			
			novaCelula = novaLinha.insertCell(5);
			novaCelula.align = "left";
			novaCelula.style.backgroundColor = cl;
			novaCelula.innerHTML = "<input type='text' name='ndiaspun["+totalspun+"]' size='1'>";
			
			novaCelula = novaLinha.insertCell(6);
			novaCelula.align = "left";
			novaCelula.style.backgroundColor = cl;
			novaCelula.innerHTML = "<input type='text' name='inipun["+totalspun+"]' size='2'>";
			
			novaCelula = novaLinha.insertCell(7);
			novaCelula.align = "left";
			novaCelula.style.backgroundColor = cl;
			novaCelula.innerHTML = "<input type='text' name='terpun["+totalspun+"]' size='2'>";
			
			novaCelula = novaLinha.insertCell(8);
			novaCelula.align = "left";
			novaCelula.style.backgroundColor = cl;
			novaCelula.innerHTML = "<input type='text' name='bipun["+totalspun+"]' size='2'>";
			
			novaCelula = novaLinha.insertCell(9);
			novaCelula.align = "left";
			novaCelula.style.backgroundColor = cl;
			novaCelula.innerHTML = "<input type='button' value='Del' id='deletepun' onclick='deleteRowPun(this.parentNode.parentNode.rowIndex)'>";

//alert(totalssv + " " +totalspun);

    }
	
 //alert(totalssv + " " +totalspun);
    </script>

<? echo'

</head>
<body>

<form action="alterarlivro2.php" method="post" enctype="multipart/form-data" name="form">
  <div align="center">
    <table width="512" border="0">
		<tr>
        <td>Of De Dia:</td>
        <td><label>';
		
		echo '<select name="ofdiaposto">
				<option value="'.$ofdiaposto.'">'.$ofdiaposto.'</option>
				<option value="1ten">1� Ten</option>
				<option value="2ten">2� Ten</option>
				<option value="asp">Asp</option>
          </select>';
		echo '
        </label>
		
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	  
       Nome Completo:
        <label>
		<input type="text" name="ofdianome" size="25" value= "'.$ofdianome.'">
        </label></td>
      </tr>
		<tr>
			<td colspan="2">
				
		<center>Data de In�cio:
		<label>';
		echo '&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="diainicio" size="4" maxlength="2" maxsize="2" value="'.$diainicio.'">';
		echo '&nbsp;/&nbsp;';
		echo '<input type="text" name="mesinicio" size="4" maxlength="2" maxsize="2" value="'.$mesinicio.'">';
		echo '&nbsp;/&nbsp;';
		echo '<input type="text" name="anoinicio" size="8" maxlength="4" maxsize="4" value="'.$anoinicio.'">';

		echo '
        </label>
		</td>
		</tr>
		<tr>
		<td colspan="2"><center>Data de T�rmino:<label>';
		
		echo '&nbsp;<input type="text" name="diatermino" size="4" maxlength="2" maxsize="2" value= "'.$diatermino.'">';
		echo '&nbsp;/&nbsp;';
		echo '<input type="text" name="mestermino" size="4" maxlength="2" maxsize="2" value= "'.$mestermino.'">';
		echo '&nbsp;/&nbsp;';
		echo '<input type="text" name="anotermino" size="8" maxlength="4" maxsize="4" value= "'.$anotermino.'">';

		echo '
        </label></td>
      </tr>
	  <tr>
        <td>Recibi do:</td>
        <td><label>';
		
		echo '<select name="recebipostograd">
				<option value="'.$recebipostograd.'">'.$recebipostograd.'</option>
				<option value="1ten">1� Ten</option>
				<option value="2ten">2� Ten</option>
				<option value="asp">Asp</option>
          </select>';
		echo '
        </label>
		
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	  
       Nome de Guerra:
        <label>';
		
		echo '<input type="text" name="recebinome" size="25" value="'.$recebinome.'">';
		echo '
        </label></td>
      </tr>
	  <tr><td colspan="2"><hr></td></tr>
	  <tr>
        <td width="72">Parada Di�ria:</td>
        <td width="430"><label>';
		
		echo '<select name="parada">
				<option value="'.$parada.'">';
				switch($parada){
					case 's1': echo 'A cargo do Ch 1� Sec</option>'	;
					break;
					case 'of': echo 'A cargo do Of de Dia</option>'	;
					break;
				}
		echo'
				<option value="s1">A cargo do Ch 1� Sec</option>
				<option value="of">A cargo do Of de Dia</option>
          </select>';
		echo '
        </label></td>
      </tr>
	    <tr>
        <td width="72">Altera��es na Parada:</td>
        <td width="430">';
		
		echo '<textarea name="alterparada" cols="45" rows="2" value="'.$alterparada.'">'.$alterparada.'</textarea>';
		echo '
        </td>
      </tr>
	   <tr>
        <td width="72">Correspond�ncia:</td>
        <td width="430"><label>';
		
		echo '<textarea name="correspondencia" cols="45" rows="2" value="'.$correspondencia.'">'.$correspondencia.'</textarea>';
		echo '
        </label></td>
      </tr>
	  <tr>
        <td width="72">Apresenta��o de Militar:</td>
        <td width="430"><label>';
		
		echo '<textarea name="apresmil" cols="45" rows="2" value="'.$apresmil.'">'.$apresmil.'</textarea>';
		echo '
        </label></td>
      </tr>
	  <tr><td colspan="2"><hr></td></tr>
	  <tr>
        <td width="72">Ronda Interna:</td>
        <td width="430"><label>';
		
		echo '<textarea name="rondaint" cols="45" rows="2" value="'.$rondaint.'">'.$rondaint.'</textarea>';
		echo '
        </label></td>
      </tr>
	  <tr>
        <td width="72">Ronda Externa:</td>
        <td width="430"><label>';
		
		echo '<textarea name="rondaext" cols="45" rows="2" value="'.$rondaext.'">'.$rondaext.'</textarea>';
		echo '
        </label></td>
      </tr>
	  <tr>
        <td width="72">Revista do Recolher:</td>
        <td width="430"><label>';
		
		echo '<select name="revistarec">
				<option value="'.$revistarec.'">';
				switch($revistarec){
					case 'sa': echo 'Sem Altera��o</option>'	;
					break;
					case 'ca': echo 'Com Altera��o</option>'	;
					break;
				}
		echo'
				<option value="sa">Sem Altera��o</option>
				<option value="ca">Com Altera��o</option>
          </select>';
		echo '
        </label></td>
      </tr>
	  <tr>
        <td width="72">Altera��o na Revista do Recolher:</td>
        <td width="430"><label>';
		
		echo '<textarea name="alterrevrec" cols="45" rows="2" value="'.$alterrevrec.'">'.$alterrevrec.'</textarea>';
		echo '
        </label></td>
      </tr>
	  <tr><td colspan="2"><hr></td></tr>
      <tr>
	  <td colspan="2">
	  
	 Pessoal de SV: 
	 <table id="tabelasv" border="0" width="100%">
        <tr style="background-color:#b0b0b0">
            <td>Fun��o</td>
			<td>Posto/Grad</td>
            <td>Nome</td>
            <td>Deletar</td>
        </tr>';
		//reconstruindo tabela pessoal sv
		
			//para checar as vari�veis descomente a linha abaixo
			//echo $Quantos; echo ' Quantos'; print_r($funcaosv);
			if ($totalssv > 0){
			$i=0;
			for ($i==0; $i<$totalssv; $i++)
						{
							
							echo '<tr><td><center>';
							//corrigindo a fun��o
							switch ($funcaosv[$i]){
								case 'orc':
									$funcaosv2[$i]='ORC';
									break;
								case 'ofdia':
									$funcaosv2[$i]='Of Dia';
									break;
								case 'adjofdia':
									$funcaosv2[$i]='Adj Of Dia';
									break;
								case 'cmtgda':
									$funcaosv2[$i]='Cmt Gda';
									break;
								case 'cbgdafte':
									$funcaosv2[$i]='Cb Gda Fte';
									break;
								case 'cbgdafun':
									$funcaosv2[$i]='Cb Gda Fun';
									break;
								case 'motdia':
									$funcaosv2[$i]='Mot Dia';
									break;	
								case 'sgtdran':
									$funcaosv2[$i]='Sgt D Ran';
									break;
								case 'clarin':
									$funcaosv2[$i]='Clarin';
									break;
								case 'comsoc':
									$funcaosv2[$i]='Com Soc';
									break;
								case 'medsbv':
									$funcaosv2[$i]='Med Sbv';
									break;
								case 'dentsbv':
									$funcaosv2[$i]='Dent Sbv';
									break;
								case 'atddia':
									$funcaosv2[$i]='Atd Dia';
									break;
								case 'eltdia':
									$funcaosv2[$i]='Elt Dia';
									break;
								case 'teldia':
									$funcaosv2[$i]='Tel Dia';
									break;
								case 'permcanil':
									$funcaosv2[$i]='Perm Canil';
									break;	
								case 'revdia':
									$funcaosv2[$i]='Rev Dia';
									break;	
									} 
									
									echo '<select name="funcaosv['.$i.']">
											<option value="'.$funcaosv[$i].'">'.$funcaosv2[$i].'</option>
											<option value="orc">ORC</option>
											<option value="ofdia">Of Dia</option>
											<option value="adjofdia">Adj Of Dia</option>
											<option value="cmtgda">Cmt Gda</option>
											<option value="cbgdafte">Cb Gda Fte</option>
											<option value="cbgdafun">Cb Gda Fun</option>
											<option value="motdia">Mot Dia</option>
											<option value="sgtdran">Sgt D Ran</option>
											<option value="clarin">Clarin</option>
											<option value="comsoc">Com Soc</option>
											<option value="medsbv">Med SBV</option>
											<option value="dentsbv">Dent SBV</option>
											<option value="atddia">Atd Dia</option>
											<option value="eltdia">Elt Dia</option>
											<option value="teldia">Tel Dia</option>
											<option value="permcanil">Perm Canil</option>
											<option value="revdia">Rev Dia</option>
										</select>';
									
							echo '</td>';
							echo '<td><center>';
							//corrigindo o posto
							switch ($postogradsv[$i]){
								case 'cap':
									$postogradsv2[$i]='cap';
									break;
								case '1ten':
									$postogradsv2[$i]='1� Ten';
									break;
								case '2ten':
									$postogradsv2[$i]='2� Ten';
									break;
								case 'asp':
									$postogradsv2[$i]='Asp';
									break;
								case '1sgt':
									$postogradsv2[$i]='1� Sgt';
									break;
								case '2sgt':
									$postogradsv2[$i]='2� Sgt';
									break;
								case '3sgt':
									$postogradsv2[$i]='3� Sgt';
									break;
								case 'cb':
									$postogradsv2[$i]='Cb';
									break;	
								case 'sdnb':
									$postogradsv2[$i]='Sd NB';
									break;
								case 'sdev':
									$postogradsv2[$i]='Sd EV';
									break;
									}  
							
							echo '<select name="postogradsv['.$i.']">
											<option value="'.$postogradsv[$i].'">'.$postogradsv2[$i].'</option>
											<option value="cap">Cap</option>
											<option value="1ten">1� Ten</option>
											<option value="2ten">2� Ten</option>
											<option value="asp">Asp</option>
											<option value="1sgt">1� Sgt</option>
											<option value="2sgt">2� Sgt</option>
											<option value="3sgt">3� Sgt</option>
											<option value="t1">T1</option>
											<option value="cb">Cb</option>
											<option value="sdnb">Sd NB</option>
											<option value="sdev">Sd EV</option>
										</select>';
							echo '</td>';
							echo '<td><center>';
							echo '<input type="text" name="nomesv['.$i.']" size="30" value="'.$nomesv[$i].'">';
							echo '</td>';
							echo "<td><input type='button' value='Delete' id='deletesv' onclick='deleteRowSv(this.parentNode.parentNode.rowIndex)'></td>";
							echo'</tr>';
						}
			
						}
						else
						{
							echo'<td colspan="3"><center>Erro! Pessoal de SV n�o encontrado.</td>';
						}
		
		
		
		
		///////////////////////////////////
		
   	echo' </table>
<br />
<input type="button" id="incluirsv" value="incluir" onclick="adicionasv()"/>
<input type="hidden" id="totalssv" name="totalssv" value="" />	 
<hr>

      Puni��es
	  <table id="tabelapun" border="0" width="100%">
        <tr style="background-color:#b0b0b0">
            <td>P/Grad</td>
			<td>Num</td>
            <td>Nome</td>
			<td>SU</td>
			<td>Punic</td>
			<td>Dias</td>
			<td>Ini</td>
			<td>Ter</td>
			<td>BI</td>
            <td>Del</td>
        </tr>';
		///////////////reconstruindo a tabela puni��es
		
		if ($totalspun > 0){
						
			$i=0;
			for ($i==0; $i<$totalspun; $i++)
						{
							
							echo '<tr><td><center>';
							//corrigindo o posto
							switch ($postogradpun[$i]){
								case 'cap':
									$postogradpun2[$i]='Cap';
									break;
								case '1ten':
									$postogradpun2[$i]='1� Ten';
									break;
								case '2ten':
									$postogradpun2[$i]='2� Ten';
									break;
								case 'asp':
									$postogradpun2[$i]='Asp';
									break;
								case '1sgt':
									$postogradpun2[$i]='1� Sgt';
									break;
								case '2sgt':
									$postogradpun2[$i]='2� Sgt';
									break;
								case '3sgt':
									$postogradpun2[$i]='3� Sgt';
									break;	
								case 't1':
									$postogradpun2[$i]='T1';
									break;	
								case 'cb':
									$postogradpun2[$i]='Cb';
									break;	
								case 'sdnb':
									$postogradpun2[$i]='Sd NB';
									break;
								case 'sdev':
									$postogradpun2[$i]='Sd EV';
									break;
									}  

							echo '<select name="postogradpun['.$i.']">
										<option value="'.$postogradpun[$i].'">'.$postogradpun2[$i].'</option>
										<option value="cap">Cap</option>
										<option value="1ten">1� Ten</option>
										<option value="2ten">2� Ten</option>
										<option value="asp">Asp</option>
										<option value="st">ST</option>
										<option value="1sgt">1� Sgt</option>
										<option value="2sgt">2� Sgt</option>
										<option value="3sgt">3� Sgt</option>
										<option value="t1">T1</option>
										<option value="cb">Cb</option>
										<option value="sdnb">Sd NB</option>
										<option value="sdev">Sd EV</option>
								</select>';
										
										
										
							echo '</td>';
							echo '<td><center>';
							
							echo '<input type="text" name="numeropun['.$i.']" size="1" value="'.$numeropun[$i].'">';
							echo '</td>';
							echo '<td><center>';
							echo '<input type="text" name="guerrapun['.$i.']" size="10" value="'.$guerrapun[$i].'">';
							echo '</td>';
							echo '<td><center>';
							//corrigindo a su
							switch ($supun[$i]){
								case '1bo':
									$supun2[$i]='1� BO';
									break;
								case '2bo':
									$supun2[$i]='2� BO';
									break;
									} 
									
							echo '<select name="supun['.$i.']">
									<option value="'.$supun[$i].'">'.convertem($supun2[$i],1).'</option>
									<option value="em">EM</option>
									<option value="1bo">1� BO</option>
									<option value="2bo">2� BO</option>
									<option value="bc">BC</option>
									<option value="aae">AAe</option>
								</select>';
									
									
							echo '</td>';
							echo '<td><center>';
							echo '<input type="text" name="punicpun['.$i.']" size="1" value="'.$punicpun[$i].'">';
							echo '</td>';
							echo '<td><center>';
							echo '<input type="text" name="ndiaspun['.$i.']" size="1" value="'.$ndiaspun[$i].'">';
							echo '</td>';
							echo '<td><center>';
							echo '<input type="text" name="inipun['.$i.']" size="2" value="'.$inipun[$i].'">';
							echo '</td>';
							echo '<td><center>';
							echo '<input type="text" name="terpun['.$i.']" size="2" value="'.$terpun[$i].'">';
							echo '</td>';
							echo '<td><center>';
							echo '<input type="text" name="bipun['.$i.']" size="2" value="'.$bipun[$i].'">';
							echo '</td>
							<td>';
							
							echo"<input type='button' value='Del' id='deletepun' onclick='deleteRowPun(this.parentNode.parentNode.rowIndex)'>";	
							echo'</td></tr>';

						}
			}
			else
			{
				echo'<tr>
						<td colspan="10">
							<center>N�O HOUVE PUNI��O.
						</td>
					</tr>';
			}
		
		/////////////////////////////////
		
    	echo '</tr></table>
	<br />
	<input type="button" id="incluirpun" value="incluir" onclick="adicionapun()"/>
	<input type="hidden" id="totalspun" name="totalspun" value="" />
  
	  </td>
	  </tr>
	  <tr><td colspan="2"><hr></td></tr>
	  <tr>
        <td width="72">Ocorr�ncias:</td>
        <td width="430">';
		
		echo '<textarea name="ocorrencias" cols="45" rows="20" value="'.$ocorrencias.'">'.$ocorrencias.'</textarea>';
		echo '
        </td>
      </tr>
	  <tr>
		<td colspan="2"><hr><br><center><strong>Parte ao Fiscal Administrativo</strong><br><hr></td>
	  </tr>
	  <tr>
        <td width="72">Material Carga:</td>
        <td width="430"><label>';
		
		echo '<textarea name="famatcarga" cols="45" rows="2" value="'.$famatcarga.'">'.$famatcarga.'</textarea>';
		echo '
        </label></td>
      </tr> 
	  <tr>
        <td width="72">Depend�ncias:</td>
        <td width="430"><label>';
		
		echo '<textarea name="fadependencias" cols="45" rows="2" value="'.$fadependencias.'">'.$fadependencias.'</textarea>';
		echo '
        </label></td>
      </tr> 
	  <tr>
        <td width="72">Tel e Alarmes:</td>
        <td width="430"><label>';
		
		echo '<textarea name="fatelalarmes" cols="45" rows="2" value="'.$fatelalarmes.'">'.$fatelalarmes.'</textarea>';
		echo '
        </label></td>
      </tr> 
	  <tr>
		<td colspan="2"><hr></td>
	  </tr>
	  <tr>
		<td colspan="2">Leitura de Energia:</td>
	  </tr>
	  <tr>
	  	<td width="72">Consumo:</td>
        <td><label>
		<input type="text" name="faenergiaconsumo" size="15" value="'.$faenergiaconsumo.'">
        </label></td>
      </tr>
	  <tr>
	  	<td width="72">Demanda:</td>
        <td><label>
		<input type="text" name="faenergiademanda" size="15" value="'.$faenergiademanda.'">
        </label></td>
      </tr>
	  <tr>
        <td width="72">Clavicul�rio:</td>
        <td width="430"><label>';
		
		echo '<textarea name="faclaviculario" cols="45" rows="2" value="'.$faclaviculario.'">'.$faclaviculario.'</textarea>';
		echo '
        </label></td>
      </tr>
	  <tr>
		<td colspan="2"><hr></td>
	  </tr> 
	  <tr>
        <td width="72">Abastecimento:</td>
        <td width="430"><label>';
		
		echo '<select name="faabastecimento">
				<option value="'.$faabastecimento.'">'.$faabastecimento.'</option>
				<option value="N�o Houve">N�o Houve</option>
				<option value="Houve">Houve</option>
          </select>';
		echo '
        </label></td>
      </tr>
	  <tr>
		<td colspan="2">VTR de Dia:</td>
	  </tr>
	  <tr>
	  	<td colspan="2">
			<table border="1">
				<tr>
					<td>
						<center>Ton</center>
					</td>
					<td>
						<center>EB</center>
					</td>
					<td>
						<center>Od Sa�da</center>
					</td>
					<td>
						<center>Od Chegada</center>
					</td>
					<td>
						<center>Diferen�a</center>
					</td>
					<td>
						<center>Obs</center>
					</td>
				</tr>
				<tr>
					<td>
					   <label>
					      <select name="favtrton">
						  		<option value="'.$favtrton.'">'.$favtrton.'</option>
								<option value="3/4">3/4</option>
								<option value="1/4">1/4</option>
								<option value="5">5</option>
								<option value="2,5">2,5</option>
								<option value="Adm">Adm</option>
						  </select>
						</label>
					</td>
					<td>
						<label>
							<input type="text" name="favtreb" size="9" value="'.$favtreb.'">
        				</label>
					</td>
					<td>
						<label>
							<input type="text" name="favtrodsaida" size="4" value="'.$favtrodsaida.'">
        				</label>
					</td>
					<td>
						<label>
							<input type="text" name="favtrodchegada" size="4" value="'.$favtrodchegada.'">
        				</label>
					</td>
					<td>
						<label>
							<input type="text" name="favtrdiferenca" size="5" value="'.$favtrdiferenca.'">
        				</label>
					</td>
					<td>
						<label>
							<textarea name="favtrobs" cols="15" rows="1" value="'.$favtrobs.'">'.$favtrobs.'</textarea>
       					 </label>
					</td>
				</tr>
			</table>
		
		<td>
	  </tr>
	  <tr>
		<td colspan="2"><hr></td>
	  </tr>
	  <tr>
        <td width="72">Po�o Artesiano:</td>
        <td width="430">
			<label>
				<textarea name="fapocoartesiano" cols="45" rows="2" value="'.$fapocoartesiano.'">'.$fapocoartesiano.'</textarea>
        	</label>
		</td>
      </tr> 
	  <tr>
        <td width="72">Luzes de Emerg�ncia:</td>
        <td width="430">
			<label>
				<textarea name="faluzemergencia" cols="45" rows="2" value="'.$faluzemergencia.'">'.$faluzemergencia.'</textarea>
        	</label>
		</td>
      </tr> 
	  <tr>
		<td colspan="2"><hr></td>
	  </tr>
	  <tr>
		<td colspan="2">Rancho:</td>
	  </tr>
	  <tr>
	  	<td width="72">Sobras:</td>
        <td><label>
		<input type="text" name="faransobras" size="15" value="'.$faransobras.'">&nbsp;Kg
        </label></td>
      </tr>
	  <tr>
	  	<td width="72">Res�duos:</td>
        <td><label>
		<input type="text" name="faranresiduos" size="15" value= "'.$faranresiduos.'">&nbsp;Kg
        </label></td>
      </tr>
	  <tr>
        <td width="72">Arranchamento:</td>
        <td width="430">
			<label>
				<textarea name="faranarranchamento" cols="45" rows="2" value="'.$faranarranchamento.'">'.$faranarranchamento.'</textarea>
        	</label>
		</td>
      </tr>
	  <tr>
        <td width="72">G�neros Recebidos:</td>
        <td width="430">
			<label>
				<textarea name="farangeneros" cols="45" rows="2" value="'.$farangeneros.'">'.$farangeneros.'</textarea>
        	</label>
		</td>
      </tr>
	  <tr>
		<td colspan="2"><hr></td>
	  </tr>
	  <tr>
        <td width="72">Muni��o:</td>
        <td width="430">
			<label>
				<textarea name="famunicao" cols="45" rows="2" value="'.$famunicao.'">'.$famunicao.'</textarea>
        	</label>
		</td>
      </tr>
	    
	  <tr><tr></td></tr>
	  <tr>
        <td width="72">Passei ao:</td>
        <td width="430"><label>';
		
		echo '<select name="passeipostograd">
				<option value="'.$passeipostograd.'">';
				switch($passeipostograd){
					case '1ten': echo '1� Ten</option>'	;
					break;
					case '2ten': echo '2� Ten</option>'	;
					break;
					case 'asp': echo 'Asp</option>'	;
					break;
				}
		echo'
				<option value="1ten">1� Ten</option>
				<option value="2ten">2� Ten</option>
				<option value="asp">Asp</option>
          </select>';
		echo '
        </label>
		
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	  
        Nome de Guerra:
        <label>';
		
		echo '&nbsp;<input type="text" name="passeinome" size="15" value= "'.$passeinome.'">';
		echo '
        </label></td>
      </tr>
	 <tr>
        <td width="72" colspan="2"><br><center>Adjunto ao Oficial de Dia&nbsp;: &nbsp;<label>
		<input type="hidden" name="postograd" size="15" value= "'.$postograd.'">
		<input type="hidden" name="guerra" size="15" value= "'.$guerra.'">';
		//corrigindo o posto
		switch ($postograd){
			case '1sgt':
				$postograd='1� SGT';
				break;
			case '2sgt':
				$postograd='2� SGT';
				break;
			case '3sgt':
				$postograd='3� SGT';
				break;	
				}  
		
		echo $postograd;
		echo '&nbsp;';
		echo convertem($guerra, 1);
		echo '
        </label></td>
      </tr>
	   
    </table>
    <p>
      <label>
	  <input type="hidden" name="idlivro" id="idlivro" value="'.$idlivro.'">
      <input type="submit" name="button" id="button" value="Salvar">
      </label>
    </p>
  </div>
</form>
<p align="center">&nbsp;</p>
</body>
</html>';
}
else
{
	echo '<center> Usu�rio n�o encontrado!<br> <a href="alterarmatricula.html" target="Display">Voltar</a>';
}
}
	else
		{
			echo '<center>Usuario n�o autorizado!';
		}
}
else
{
	echo '<center>Usuario n�o autorizado!';
}
?>
