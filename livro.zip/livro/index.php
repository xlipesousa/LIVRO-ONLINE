<?
if ($HTTP_POST_VARS['entrar'] == 'Entrar!')
@session_start("usuarios");

 include "base.php"; 
?>

<HTML>
<HEAD>
	<TITLE>Livro Online - 2&ordm;GAC L</TITLE>
	<STYLE type=text/css>A:link {
	COLOR: #003399; TEXT-DECORATION: none
}
A:visited {
	COLOR: #0066CC; TEXT-DECORATION: none
}
A:active {
	COLOR: #0066CC
}
A:hover {
	COLOR: #0066CC; TEXT-DECORATION: overline underline
}
BODY {
	SCROLLBAR-FACE-COLOR: #ffffff; SCROLLBAR-HIGHLIGHT-COLOR: #ffffff; 
	SCROLLBAR-SHADOW-COLOR: #0066CC; SCROLLBAR-3DLIGHT-COLOR: #0066CC; 
	SCROLLBAR-ARROW-COLOR: #0066CC; SCROLLBAR-TRACK-COLOR: #ffffff; 
	SCROLLBAR-DARKSHADOW-COLOR: #ffffff; BACKGROUND-COLOR: #ffffff
}
</STYLE>





<SCRIPT LANGUAGE="JavaScript">
<!--

function newImage(arg) 
{
	if (document.images) 
	{
		rslt = new Image();
		rslt.src = arg;
		return rslt;
	}
}

// -->
    </SCRIPT>
	
</HEAD>
<body background="bg005.jpg">
<table width="755" border="1" cellpadding="0" cellspacing="0" align="center">
  <tr> 
    <td height="131" colspan="4" valign="top"><p><img src="imagens/bluestripe.jpg" width="750" height="131"></p>
    </td>
  </tr>
  <tr> 
    <td width="9" height="2"></td>
    <td width="157"></td>
    <td width="8"></td>
    <td width="581"></td>
  </tr>
  <tr> 
    <td height="454">&nbsp;</td>
    <td valign="top"><TABLE border="1" cellpadding="3" cellspacing="0" style="border-collapse: collapse; border-style: solid; border-width: 1; padding-left: 4; padding-right: 4; padding-top: 1; padding-bottom: 1" bordercolor="#999999" width="99%" id="AutoNumber4" bgcolor="#E6EDF7">
        <TR> 
          <TD width="100%" bordercolor="#E6EDF7">
		  <?
				if ($HTTP_POST_VARS['entrar'] == 'Entrar!')
				{
					$result = mysql_query('select usuario, senha, nivel, id, guerra, nome from usuarios where usuario="'.trim($usuario).'";',$conexaolivro);
					if (mysql_num_rows($result)>0)
						{
							$usuSenha=mysql_result($result,0,senha);
							$nome=mysql_result($result,0,nome);
							$id=mysql_result($result,0,id);
							$guerra=mysql_result($result,0,guerra);
						}
					else
						{
							$usuSenha = 'notuser';
						}
					if ($result and ($senha==$usuSenha) and ($usuSenha<>'notuser'))
						{
							$nivel = mysql_result($result,0,nivel);	
							session_register($usuario,$nivel);
							$_SESSION['nivel'] = $nivel;
							
							$id = mysql_result($result,0,id);
							session_register($usuario,$id);
							$_SESSION['id'] = $id;
							
							echo '<p align="center">';
							echo $guerra.'<br>';
							echo 'Voc� est� on-line';
							echo '</p>';
							
						}
					else
						{
							session_destroy();
							echo '<center>';
							echo 'Usu�rio n�o autorizado<br>';
							echo '<form method = "post" name = "Logar" action = "">
						
						Login: <input type="text" name="usuario" value="" size="15"><br>
						Senha: <input type="password" name="senha" value="" size="15"><br>
						
						<p align="center">
						<input onmouseover=this.style.cursor="hand" type="submit" name="entrar" value="Entrar!" class="style5">
					
					</form>';
						}
					}
				else
					{
						echo '<form method = "post" name = "Logar" action = "">
						Login: <input type="text" name="usuario" value="" size="15"><br>
						Senha: <input type="password" name="senha" value="" size="15"><br>
						<p align="center">
						<input onmouseover=this.style.cursor="hand" type="submit" name="entrar" value="Entrar!" class="style5">
					</p>
					</form>';
				}
			
			if (session_is_registered($usuario))
			{
		echo'<form name="form1" method="post" action="LogOut.php" target="_parent">
		  <label>
		  <center><input type="submit" class="style5" name="sair" value="Sair"></center>
		    </label>
		  </form>';
		  }
		  ?>
		  </td>
        </TR>
        <TR> 
          <TD bordercolor="#E6EDF7"> 
         
		  <?
		  if (session_is_registered($usuario))
			{
			echo'  <TABLE border="0" cellpadding="3" cellspacing="0">
			<tr>
			<td>';
			echo'</td></tr>';
             //administrador
			 
			 if($nivel == "1"){ /* se o n�vel do usu�rio for 1 */
				echo '
				<TR> 
                <TD width="163" height="25" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. <a href="inicio.html" target="Display">P&aacute;gina Inicial </a></font>  				 				</TD>
              </TR> 
			  <TR> 
                <TD width="163" height="25" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. <a href="cadastrar.html" target="Display">Cadastro</a></font>  				 				
				</TD>
			  </tr>
			  <tr>
				<TD width="163" height="25" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. <a href="caixaentradas1.php" target="Display">Caixa de Entrada</a></font>  				 				
				</TD>
              </TR>
			  <TR> 
                <TD height="28" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. 
                <a href="historico.php" target="Display">Hist�rico</a></font></TD>
              </TR>
			  <TR> 
                <TD height="28" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. 
                <a href="cadastro.php" target="Display">Cadastro</a></font></TD>
              </TR>
			  <tr>
				<TD width="163" height="25" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. <a href="alterasenhausuario.php" target="Display">Alterar Senha</a></font>  				 				
				</TD>
              </TR>
			  <tr>
				<TD width="163" height="25" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. <a href="senhausuario.php" target="Display">Senha de Usuarios</a></font>  				 				
				</TD>
              </TR>
			  <TD width="163" height="25" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. <a href="planochamada.php" target="Display">Plano de Chamada</a></font>  				 				
				</TD>
              </TR>';
				}
			 
			 //usuario normal
			 if($nivel == "2"){ /* se o n�vel do usu�rio for 2 */
				echo ' 
			  <TR> 
                <TD width="163" height="25" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. <a href="inicio.html" target="Display">P&aacute;gina Inicial </a></font>  				 				</TD>
              </TR>
              <TR> 
                <TD height="25" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. <a href="novo.php" target="Display">Novo Livro</a></font></TD>
              </TR>';
				echo'
              
              <TR> 
                <TD height="28" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. 
                <a href="meuslivros.php" target="Display">Meus Livros</a></font></TD>
              </TR>
			  <TR> 
                <TD height="28" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. 
                <a href="outroslivros.php" target="Display">Outros Livros</a></font></TD>
              </TR>
			  <TR> 
                <TD height="28" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. 
                <a href="cadastro.php" target="Display">Cadastro</a></font></TD>
              </TR>
			  <TR> 
                <TD height="28" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. 
                <a href="alterasenhausuario.php" target="Display">Alterar Senha</a></font></TD>
              </TR>
			  <TD width="163" height="25" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. <a href="planochamada.php" target="Display">Plano de Chamada</a></font>  				 				
				</TD>
              </TR>';
			  }
			 if($nivel == "3"){ /* se o n�vel do usu�rio for  scmt */
				echo ' 
			  <TR> 
                <TD width="163" height="25" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. <a href="inicio.html" target="Display">P&aacute;gina Inicial </a></font>  				 				</TD>
              </TR>
              <TR> 
                <TD height="25" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. <a href="caixaentrada.php" target="Display">Caixa de Entrada</a></font></TD>
              </TR>';
				echo'
			  <TR> 
                <TD height="28" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. 
                <a href="historico.php" target="Display">Hist�rico</a></font></TD>
              </TR>
			  <TR> 
                <TD height="28" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. 
                <a href="cadastro.php" target="Display">Cadastro</a></font></TD>
              </TR>
			  <TR> 
                <TD height="28" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. 
                <a href="alterasenhausuario.php" target="Display">Alterar Senha</a></font></TD>
              </TR>
			  ';
			  }
			  	if($nivel == "4"){ /* se o n�vel do usu�rio for 4 */
				echo '
				<TR> 
                <TD width="163" height="25" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. <a href="inicio.html" target="Display">P&aacute;gina Inicial </a></font>  				 				</TD>
              </TR> 
			  <tr>
				<TD width="163" height="25" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. <a href="caixaentradas2.php" target="Display">Caixa de Entrada</a></font>  				 				
				</TD>
              </TR>
			  <TR> 
                <TD height="28" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. 
                <a href="historico.php" target="Display">Hist�rico</a></font></TD>
              </TR>
			  <TR> 
                <TD height="28" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. 
                <a href="cadastro.php" target="Display">Cadastro</a></font></TD>
              </TR>
			  <tr>
				<TD width="163" height="25" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. <a href="alterasenhausuario.php" target="Display">Alterar Senha</a></font>  				 				
				</TD>
              </TR>';
				}
				if($nivel == "5"){ /* se o n�vel do usu�rio for 5 */
				echo '
				<TR> 
                <TD width="163" height="25" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. <a href="inicio.html" target="Display">P&aacute;gina Inicial </a></font>  				 				</TD>
              </TR> 
			  <tr>
				<TD width="163" height="25" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. <a href="caixaentradas3.php" target="Display">Caixa de Entrada</a></font>  				 				
				</TD>
              </TR>
			  <TR> 
                <TD height="28" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. 
                <a href="historico.php" target="Display">Hist�rico</a></font></TD>
              </TR>
			  <TR> 
                <TD height="28" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. 
                <a href="cadastro.php" target="Display">Cadastro</a></font></TD>
              </TR>
			  <tr>
				<TD width="163" height="25" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. <a href="alterasenhausuario.php" target="Display">Alterar Senha</a></font>  				 				
				</TD>
              </TR>';
				}
			 if($nivel == "6"){ /* se o n�vel do usu�rio for 6 */
				echo '
				<TR> 
                <TD width="163" height="25" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. <a href="inicio.html" target="Display">P&aacute;gina Inicial </a></font>  				 				</TD>
              </TR> 
			  <tr>
				<TD width="163" height="25" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. <a href="caixaentradas4.php" target="Display">Caixa de Entrada</a></font>  				 				
				</TD>
              </TR>
			  <TR> 
                <TD height="28" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. 
                <a href="historico.php" target="Display">Hist�rico</a></font></TD>
              </TR>
			  <TR> 
                <TD height="28" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. 
                <a href="cadastro.php" target="Display">Cadastro</a></font></TD>
              </TR>
			  <tr>
				<TD width="163" height="25" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. <a href="alterasenhausuario.php" target="Display">Alterar Senha</a></font>  				 				
				</TD>
              </TR>';
				}
				 if($nivel == "7"){ /* se o n�vel do usu�rio for 7 */
				echo '
				<TR> 
                <TD width="163" height="25" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. <a href="inicio.html" target="Display">P&aacute;gina Inicial </a></font>  				 				</TD>
              </TR> 
			  <tr>
				<TD width="163" height="25" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. <a href="caixaentradabo1.php" target="Display">Caixa de Entrada</a></font>  				 				
				</TD>
              </TR>
			  <TR> 
                <TD height="28" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. 
                <a href="historico.php" target="Display">Hist�rico</a></font></TD>
              </TR>
			  <TR> 
                <TD height="28" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. 
                <a href="cadastro.php" target="Display">Cadastro</a></font></TD>
              </TR>
			  <tr>
				<TD width="163" height="25" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. <a href="alterasenhausuario.php" target="Display">Alterar Senha</a></font>  				 				
				</TD>
              </TR>';
				}
				 if($nivel == "8"){ /* se o n�vel do usu�rio for 8 */
				echo '
				<TR> 
                <TD width="163" height="25" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. <a href="inicio.html" target="Display">P&aacute;gina Inicial </a></font>  				 				</TD>
              </TR> 
			  <tr>
				<TD width="163" height="25" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. <a href="caixaentradabo2.php" target="Display">Caixa de Entrada</a></font>  				 				
				</TD>
              </TR>
			  <TR> 
                <TD height="28" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. 
                <a href="historico.php" target="Display">Hist�rico</a></font></TD>
              </TR>
			  <TR> 
                <TD height="28" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. 
                <a href="cadastro.php" target="Display">Cadastro</a></font></TD>
              </TR>
			  <tr>
				<TD width="163" height="25" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. <a href="alterasenhausuario.php" target="Display">Alterar Senha</a></font>  				 				
				</TD>
              </TR>';
				}
				 if($nivel == "9"){ /* se o n�vel do usu�rio for 9 */
				echo '
				<TR> 
                <TD width="163" height="25" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. <a href="inicio.html" target="Display">P&aacute;gina Inicial </a></font>  				 				</TD>
              </TR> 
			  <tr>
				<TD width="163" height="25" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. <a href="caixaentradabc.php" target="Display">Caixa de Entrada</a></font>  				 				
				</TD>
              </TR>
			  <TR> 
                <TD height="28" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. 
                <a href="historico.php" target="Display">Hist�rico</a></font></TD>
              </TR>
			  <TR> 
                <TD height="28" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. 
                <a href="cadastro.php" target="Display">Cadastro</a></font></TD>
              </TR>
			  <tr>
				<TD width="163" height="25" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. <a href="alterasenhausuario.php" target="Display">Alterar Senha</a></font>  				 				
				</TD>
              </TR>';
				}
				 if($nivel == "10"){ /* se o n�vel do usu�rio for 10 */
				echo '
				<TR> 
                <TD width="163" height="25" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. <a href="inicio.html" target="Display">P&aacute;gina Inicial </a></font>  				 				</TD>
              </TR> 
			  <tr>
				<TD width="163" height="25" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. <a href="caixaentradaaae.php" target="Display">Caixa de Entrada</a></font>  				 				
				</TD>
              </TR>
			  <TR> 
                <TD height="28" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. 
                <a href="historico.php" target="Display">Hist�rico</a></font></TD>
              </TR>
			  <TR> 
                <TD height="28" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. 
                <a href="cadastro.php" target="Display">Cadastro</a></font></TD>
              </TR>
			  <tr>
				<TD width="163" height="25" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. <a href="alterasenhausuario.php" target="Display">Alterar Senha</a></font>  				 				
				</TD>
              </TR>';
				}
				if($nivel == "11"){ /* se o n�vel do usu�rio for 11 */
				echo '
				<TR> 
                <TD width="163" height="25" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. <a href="inicio.html" target="Display">P&aacute;gina Inicial </a></font>  				 				</TD>
              </TR> 
			  <tr>
				<TD width="163" height="25" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. <a href="caixaentradafiscal.php" target="Display">Caixa de Entrada</a></font>  				 				
				</TD>
              </TR>
			  <TR> 
                <TD height="28" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. 
                <a href="historico.php" target="Display">Hist�rico</a></font></TD>
              </TR>
			  <TR> 
                <TD height="28" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. 
                <a href="cadastro.php" target="Display">Cadastro</a></font></TD>
              </TR>
			  <tr>
				<TD width="163" height="25" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. <a href="alterasenhausuario.php" target="Display">Alterar Senha</a></font>  				 				
				</TD>
              </TR>';
				}


			  
			  if($nivel == "0" || $nivel == "00"){ /* se o n�vel do usu�rio for 0 ou 00 */
				echo'
              <TR> 
                <TD height="25" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. <a href="faltas.html" target="Display">Lan&ccedil;ar Falta</a></font></TD>
              </TR>
              <TR> 
                <TD height="25" valign="top"><font size="1.5" face="Verdana, Arial, Helvetica, sans-serif">:. 
                <a href="fo.html" target="Display">    Lan&ccedil;ar FO </a></font></TD>
              </TR>';
			  }
			   /* nesta �rea entre echo e </table> inserir links comuns a todos os usuarios*/
			  echo'
              
			  
			  
			  
            </TABLE>';
					
				 }
          ?>
		
		  </TD>
        </TR>
      </TABLE>
	  <p>&nbsp;</p></td>
    <td>
	</td>
    <td valign="top"><table width="100%" height="429" border="1" cellpadding="3" cellspacing="0" bordercolor="#CCCCCC" bgcolor="#FFFFFF">
        <!--DWLayoutTable-->
        <tr> 
          <td width="526" height="452">
			<iframe align="right" name=Display src="inicio.html" frameborder="0" scrolling="0" height="1200" width="100%"> seu navegador n�o oferece suporte a quadros ';
		  </td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td height="17"></td>
    <td></td>
    <td></td>
    <td><div align="center"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">2&ordm; GAC L - Desenvolvido por Sgt Pedrosa - 1&ordf; Bia O - V1 </font></div></td>
  </tr>
</table>
</body>
</html>
