<?
session_start();
include "base.php";
if (isset($_SESSION['nivel'])) 
{
 	$logado = $_SESSION['nivel'];
	$idusuaario = $_SESSION['id'];
  	if ($logado)
	{		
		echo'<html>
		<head>
		<title>Arquivar</title>
		</head>
		<body>';
		//recebendo vari�vel
		//retirando as oespa�os e aspas		
		$secao= $HTTP_POST_VARS[secao];
		$idlivro= $HTTP_POST_VARS[idlivro];
		
		switch($secao)
		{
		  case 'fiscal': //inserindo no banco		
		$result = mysql_query("UPDATE livro SET fiscalcheck='s' WHERE id='".$idlivro."';",$conexaolivro);
		  break;
		  case 's1': //inserindo no banco		
		$result = mysql_query("UPDATE livro SET s1check='s' WHERE id='".$idlivro."';",$conexaolivro);
		  break;
		  case 's2': //inserindo no banco		
		$result = mysql_query("UPDATE livro SET s2check='s' WHERE id='".$idlivro."';",$conexaolivro);
		  break;
		  case 's3': //inserindo no banco		
		$result = mysql_query("UPDATE livro SET s3check='s' WHERE id='".$idlivro."';",$conexaolivro);
		  break;
		  case 's4': //inserindo no banco		
		$result = mysql_query("UPDATE livro SET s4check='s' WHERE id='".$idlivro."';",$conexaolivro);
		  break;
		  case 'bo1': //inserindo no banco		
		$result = mysql_query("UPDATE livro SET bo1check='s' WHERE id='".$idlivro."';",$conexaolivro);
		  break;
		  case 'bo2': //inserindo no banco		
		$result = mysql_query("UPDATE livro SET bo2check='s' WHERE id='".$idlivro."';",$conexaolivro);
		  break;
		  case 'bc': //inserindo no banco		
		$result = mysql_query("UPDATE livro SET bccheck='s' WHERE id='".$idlivro."';",$conexaolivro);
		  break;
		  case 'aae': //inserindo no banco		
		$result = mysql_query("UPDATE livro SET aaecheck='s' WHERE id='".$idlivro."';",$conexaolivro);
		  break;
		  
		}
       
		if ($result)
			{
			echo '<center>Despacho Marcado como Lido!';
			}
		else
			{
				echo '<center> Erro ao Marcar Despacho como Lido! Contate o Administrador!';
			}
	
		}
			else
				{
					echo '<center>Usuario n�o autorizado!';
				}
		}
else
{
	echo '<center>Usuario n�o autorizado!';
}
?>

</body>
</body>
</html>
