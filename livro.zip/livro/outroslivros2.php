<?
include "base.php";
session_start("usuarios");
$logado = $_SESSION['nivel'];
if ($logado == '2')
		{
		?>
		<html>
			<head>
			<title>Consultar Meus livros</title>
			<script>function checar(pagina,texto) { if (confirm("DSEJA REALMENTE DELETAR ESTE LIVRO?")==true) { window.location=pagina; } }</script>
			<script language="JavaScript">
				function mudacelula(){
					var cor = "#FFFF75";
					var elemento = document.getElementById("teste");
					elemento.style.backgroundColor = cor;
				}
			</script>
			</head>

		<body>
		<table width="500" height="97" border="0" cellpadding="0" cellspacing="0">
           <tr> 
               <td valign="top"><div align="center"><img src="../livro/imagens/livro.jpg"></div></td>
  			</tr>
  			<tr> 
   			<td height="19"> 
				  <?php
				  
				  //formatando data
					$datainicio = "".$HTTP_POST_VARS['anoinicio']."-".$_POST['mesinicio']."-".$_POST['diainicio']."";
					$datatermino = "".$HTTP_POST_VARS['anotermino']."-".$_POST['mestermino']."-".$_POST['diatermino']."";
					//consultando no banco		
					$qryt = mysql_query("SELECT id, diainicio,mesinicio,anoinicio, ofdiaposto,ofdianome FROM livro WHERE datainicio BETWEEN '".$datainicio."' AND '".$datatermino."' order by id desc;",$conexaolivro);
				$totalreg = mysql_num_rows($qryt);
				$i = 0; 
				?>
      			<div align="center"> 
                        <table width="540" border="0" cellpadding="0" cellspacing="0" bgcolor="#999999">
							<tr>
								<td width="95"><center>Cod Livro
								</td>
								<td width="120"><center>Data SV
								</td>
								<td width="80"><center>Of Dia
								</td>
								<td width="80"><center>Ler
								</td>
							</tr>
							<?php
							if ($totalreg < 1){
							echo "<tr><td width=\"440\"><div align=\"center\"><font class=\"font1\"><i><br><br>Nenhum <u>Livro</u> Encontrado!</i></font></div></td></tr>";
							} else {
							
					while ($reg = mysql_fetch_array($qryt, MYSQL_ASSOC)){
							$idlivro = mysql_result($qryt,$i,id);
							$diainicio = mysql_result($qryt,$i,diainicio);
							$mesinicio = mysql_result($qryt,$i,mesinicio);
							$anoinicio = mysql_result($qryt,$i,anoinicio);
							$ofdiaposto = mysql_result($qryt,$i,ofdiaposto);
							$ofdianome = mysql_result($qryt,$i,ofdianome);
							
							//corrigindo o posto do of dia
							switch ($ofdiaposto){
								case '1ten':
      								$ofdiaposto='1� Ten';
     								break;
								case '2ten':
      								$ofdiaposto='2� Ten';
     								break;
								case 'asp':
      								$ofdiaposto='Asp';
     								break;
									}
									
					?>
						   <tr id="teste" onMouseOver="this.style.backgroundColor='#C1FFC1'" onMouseOut="this.style.backgroundColor='<?=($i % 2 == 0 ? "#F7F7F7" : "#E6E6E6")?>'" bgcolor="<?=($i % 2 == 0 ? "#F7F7F7" : "#E6E6E6")?>"> 
						   
						   
							<td  height="19"><font class="font1"><center><?php echo $idlivro; ?></font></td>
							
							
							<td  height="19"><font class="font1"><center><?php echo $diainicio; echo'/';echo $mesinicio; echo'/'; echo $anoinicio; ?></font></td>
							
							
							<td  height="19"><font class="font1"><center><?php echo $ofdiaposto; echo'&nbsp;'; echo $ofdianome; ?></font></td>
							
							
							<td><div align="center"><a href="../livro/lerlivro.php?idlivro=<?= $idlivro ?>" target="_blank"><img src="../livro/imagens/ler.png" border="0" alt="Ler"></a></div></td>
						  </tr>
						  <?php
					$i++;
						}
					}
					?>
						</table><p></p>
      </div></td>
  </tr>
</table>
			
		</body>
		</html>
<?
		}
	else
	{echo '
	<htm>
<head>
<title>Outros Livros</title>
</head>
<body>
	<center>Usuario n�o autorizado!
	
	</body>
</html>';

	}
	?>