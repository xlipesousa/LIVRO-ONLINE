<?
session_start();
include "base.php";
if (isset($_SESSION['nivel'])) 
{
 	$logado = $_SESSION['nivel'];
  	if ($logado)
	{
	$idusuario = $_SESSION['id'];
	//selecionando dados do usuario
	$result = mysql_query("SELECT * FROM usuarios WHERE id ='".$idusuario."';",$conexaolivro);
	$Quantos = mysql_num_rows($result);
	if($Quantos > 0)
	{
	//iniciando vari�veis
	
	$postograd= mysql_result($result,0,postograd);
	$nome= mysql_result($result,0,nome);
	$guerra= mysql_result($result,0,guerra);
	$idt= mysql_result($result,0,idt);
	$su= mysql_result($result,0,su);
	//corrigindo o posto/gradua��o
		switch ($postograd){
		
			case 'tc':
				$postogradselect='TC';
				break;
			case 'maj':
				$postogradselect='MAJ';
				break;
			case 'cap':
				$postogradselect='Cap';
				break;
			case '1ten':
				$postogradselect='1� Ten';
				break;
			case '2ten':
				$postogradselect='2� Ten';
				break;
			case 'asp':
				$postogradselect='Asp';
				break;
			case '1sgt':
				$postogradselect='1� Sgt';
				break;
			case '2sgt':
				$postogradselect='2� Sgt';
				break;
			case '3sgt':
				$postogradselect='3� Sgt';
				break;
				}

				//corrigindo o su
		switch ($su){
		
			case 'em':
				$suselect='EM';
				break;
			case '1bo':
				$suselect='1� BO';
				break;
			case '2bo':
				$suselect='2� BO';
				break;
			case 'bc':
				$suselect='BC';
				break;
			case 'aae':
				$suselect='AAe';
				break;
				}


echo '

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title> Altualizar Cadastro</title>
</head>
<body>

<div align="center">
  <p>Dados do Cadastro Atual</p>
</div>
<form action="cadastro2.php" method="post" enctype="multipart/form-data" name="alterar">
  <div align="center">
    <table width="512" border="0">
	
	
	<tr>
        <td width="150">Posto/Grad</td>
        <td><label>
		   <select name="postograd">';
		
         echo '<option value="'.$postograd.'">"'.$postogradselect.'"</option>';
		 echo '<option value="tc">TC</option>
			  <option value="maj">Maj</option>
			  <option value="cap">Cap</option>
			  <option value="1ten">1� Ten</option>
			  <option value="2ten">2� Ten</option>
			  <option value="asp">Asp</option>
			  <option value="1sgt">1� Sgt</option>
			  <option value="2sgt">2� Sgt</option>
			  <option value="3sgt">3� Sgt</option>
          </select>
';
		echo '
        </label></td>
      </tr>
	  <tr>
        <td width="150">Nome de Guerra:</td>
        <td><label>';
		
		echo '<input type="text" name="guerra" size="30" value= "'.$guerra.'">';
		echo '
        </label></td>
      </tr>
	  <tr>
        <td width="150">Nome Completo:</td>
        <td><label>';
		
		echo '<input type="text" name="nome" size="40" value= "'.$nome.'">';
		echo '
        </label></td>
      </tr>
	  <tr>
        <td width="150">Identidade:</td>
        <td><label>';
		
		echo '<input type="text" name="idt" size="20" value= "'.$idt.'">';
		echo '
        </label></td>
      </tr>
	    <tr>
        <td width="150">SU</td>
        <td><label>
		   <select name="su">';
		
         echo '<option value="'.$su.'">"'.$suselect.'"</option>';
		 echo '<option value="em">EM</option>
			  <option value="1bo">1� BO</option>
			  <option value="2bo">2� BO</option>
			  <option value="bc">BC</option>
			  <option value="aae">AAe</option>
          </select>
';
		echo '
        </label></td>
      </tr>
	 </table>
    <p>
      <label>
      <input type="submit" name="Submit" value="Salvar">
      </label>
    </p>
  </div>
</form>
<p align="center">&nbsp;</p>
</body>
</html>';
}
else
{
	echo '<center> Usu�rio n�o encontrado!<br>';
}
}
	else
		{
			echo '<center>Usuario n�o autorizado!';
		}
}
else
{
	echo '<center>Usuario n�o autorizado!';
}
?>
