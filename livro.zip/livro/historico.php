<?
session_start();
include "base.php";
if (isset($_SESSION['nivel'])) 
{
 	$logado = $_SESSION['nivel'];
  	if ($logado)
	{
	echo'
	<center>Buscar Por Per�odo</center><br>
<form name="form1" method="post" action="historico2.php">
  <table align="center" size="500" border="0">
  <tr>
  	<td>
  De:
  	</td>
	<td>
    <input type="text" name="diainicio" size="4" maxlength="2" >
/ 
<input type="text" name="mesinicio" size="4"  maxlength="2">
/
<input type="text" name="anoinicio" size="8" maxlength="4">
	</td>
	</tr>
    <tr>
		<td>
		At�: 
  		</td>
		<td>
  <input type="text" name="diatermino" size="4" >
/ 
<input type="text" name="mestermino" size="4" >
/
<input type="text" name="anotermino" size="8" >
</td>
</tr>
<tr>
	<td colspan ="2">
	  <p align="center">
		<label>
		<input type="submit" name="Submit" value="Pesquisar">
		</label>
	</p>
</td>
</tr>
</table>
</form>';

}
	else
		{
			echo '<center>Usuario n�o autorizado!';
		}
}
else
{
	echo '<center>Usuario n�o autorizado!';
}
?>
