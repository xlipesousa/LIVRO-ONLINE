<?
include "base.php";
		$postograd = $_POST["postograd"];
		$guerra = $_POST["guerra"];
		$nome = $_POST["nome"];
		$idt = $_POST["idt"];
		$su = $_POST["su"];
		$usuario = $_POST["login"];
		$senha = $_POST["senha"];
		$nivel = $_POST["nivel"];
		
		$result = mysql_query('insert into usuarios (postograd,guerra,nome,idt,su,usuario,senha,nivel) values("'.$postograd.'","'.$guerra.'","'.$nome.'","'.$idt.'","'.$su.'","'.$usuario.'","'.$senha.'","'.$nivel.'");',$conexaolivro);
		if ($result)
			{
			echo '
				<html>
					<head>
						<title>Cadastrar</title>
						</head>
						<body>
							<center>Cadastro efetuado com Sucesso!
							<br>Efetue seu Login para continuar.
						</body>
				</html>';
			}
		else
			{	echo '
				<html>
					<head>
					<title>Cadastrar</title>
					</head>
					<body>
			 			<center>Erro ao Cadastrar! <br> Nome de usu�rio j� existente ou dados inv�lidos.<br>
						<a href="cadastrar.php" target="Display">VOLTAR</a>
					</body>
				</html>';
			}
		
?>
