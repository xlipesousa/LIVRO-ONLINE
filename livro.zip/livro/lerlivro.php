<?
session_start();
include "base.php";
if (isset($_SESSION['nivel'])) 
{
  $logado = $_SESSION['nivel'];
		echo '
		<html>
		<head>
		<title>Livro Online</title>
		</head>
		<body>';
		if ((((((((((($logado == '1')||($logado == '2')) || ($logado == '3')) || ($logado == '4')) || ($logado == '5')) || ($logado == '6')) || ($logado == '7')) || ($logado == '8')) || ($logado == '9')) || ($logado == '10')) || ($logado == '11'))
		{
		//recebendo vari�vel com c�digo do livro
		$idlivro = $_GET["idlivro"];
		
		//buscando dados do livro no banco de dados
		$result = mysql_query("SELECT * FROM livro WHERE id='". $idlivro ."';",$conexaolivro);	
		$Quantos = mysql_num_rows($result);
		
		//desenhando o livro
		if($Quantos)
		{
			//recebendo vari�vel		
			$idusuario = mysql_result($result,0,idusuario);
			$diainicio = mysql_result($result,0,diainicio);
			$mesinicio = mysql_result($result,0,mesinicio);;
			$anoinicio = mysql_result($result,0,anoinicio);
			$diatermino = mysql_result($result,0,diatermino);
			$mestermino = mysql_result($result,0,mestermino);
			$anotermino = mysql_result($result,0,anotermino);	
			$ofdiaposto = mysql_result($result,0,ofdiaposto); 
			$ofdianome = mysql_result($result,0,ofdianome);
			$recebipostograd = mysql_result($result,0,recebipostograd); 
			$recebinome = mysql_result($result,0,recebinome);
			$parada = mysql_result($result,0,parada); 
			$alterparada = mysql_result($result,0,alterparada);
			$correspondencia = mysql_result($result,0,correspondencia);
			$apresmil = mysql_result($result,0,apresmil);
			$rondaint = mysql_result($result,0,rondaint);
			$rondaext = mysql_result($result,0,rondaext);
			$revistarec = mysql_result($result,0,revistarec);; 
			$alterrevrec = mysql_result($result,0,alterrevrec);
			$pessoalsv = mysql_result($result,0,pessoalsv);
			$punicoes = mysql_result($result,0,punicoes);
			$ocorrencias = mysql_result($result,0,ocorrencias);
			$passeipostograd = mysql_result($result,0,passeipostograd);
			$passeinome = mysql_result($result,0,passeinome);
			$adjgrad = mysql_result($result,0,adjgrad);
			$adjnome = mysql_result($result,0,adjnome);
			
			//recebendo dados da tabela sv 
			$funcaosv = mysql_result($result,0,funcaosv);
			$postogradsv = mysql_result($result,0,postogradsv);
			$nomesv = mysql_result($result,0,nomesv);
			
					
			//recebendo dados da tabela puni��es
			$postogradpun = mysql_result($result,0,postogradpun);
			$numeropun = mysql_result($result,0,numeropun);
			$guerrapun = mysql_result($result,0,guerrapun);
			$supun = mysql_result($result,0,supun);
			$punicpun = mysql_result($result,0,punicpun);
			$ndiaspun = mysql_result($result,0,ndiaspun);
			$inipun = mysql_result($result,0,inipun);
			$terpun = mysql_result($result,0,terpun);
			$bipun = mysql_result($result,0,bipun);
			
			$datainicio = mysql_result($result,0,datainicio);
			$datatermino = mysql_result($result,0,datatermino);
			
			//recebendo dados da parte do fiscal administrativo
			$famatcarga = mysql_result($result,0,famatcarga);
			$fadependencias = mysql_result($result,0,fadependencias);
			$fatelalarmes = mysql_result($result,0,fatelalarmes);
			$faenergiaconsumo = mysql_result($result,0,faenergiaconsumo);
			$faenergiademanda = mysql_result($result,0,faenergiademanda);
			$faclaviculario = mysql_result($result,0,faclaviculario);
			$faabastecimento = mysql_result($result,0,faabastecimento);
			$favtrton = mysql_result($result,0,favtrton);
			$favtreb = mysql_result($result,0,favtreb);
			$favtrodsaida = mysql_result($result,0,favtrodsaida);
			$favtrodchegada = mysql_result($result,0,favtrodchegada);
			$favtrdiferenca = mysql_result($result,0,favtrdiferenca);
			$favtrobs = mysql_result($result,0,favtrobs);
			$fapocoartesiano = mysql_result($result,0,fapocoartesiano);
			$faluzemergencia = mysql_result($result,0,faluzemergencia);
			$faransobras = mysql_result($result,0,faransobras);
			$faranresiduos = mysql_result($result,0,faranresiduos);
			$faranarranchamento = mysql_result($result,0,faranarranchamento);
			$farangeneros = mysql_result($result,0,farangeneros);
			$famunicao = mysql_result($result,0,famunicao);
			
			
			//parte dois: despacho
			$despachado = mysql_result($result,0,despachado);
			if ($despachado == "s")
			{		
					$fiscaldespacho = mysql_result($result,0,fiscaldespacho);
					$s1despacho = mysql_result($result,0,s1despacho);
					$s2despacho = mysql_result($result,0,s2despacho);
					$s3despacho = mysql_result($result,0,s3despacho);
					$s4despacho = mysql_result($result,0,s4despacho);
					$bo1despacho = mysql_result($result,0,bo1despacho);
					$bo2despacho = mysql_result($result,0,bo2despacho);
					$bcdespacho = mysql_result($result,0,bcdespacho);
					$aaedespacho = mysql_result($result,0,aaedespacho);
					$s1check = mysql_result($result,0,s1check);
					$s2check = mysql_result($result,0,s2check);
					$s3check = mysql_result($result,0,s3check);
					$s4check = mysql_result($result,0,s4check);
					$bo1check = mysql_result($result,0,bo1check);
					$bo2check = mysql_result($result,0,bo2check);
					$bccheck = mysql_result($result,0,bccheck);
					$aaecheck = mysql_result($result,0,aaecheck);
					$fiscalcheck = mysql_result($result,0,fiscalcheck);
					//formatando o despacho
					if ($fiscaldespacho == "")
					{
						$fiscaldespacho = "NADA HOUVE";
						$fiscalcheck = "";
					}
					if ($s1despacho == "")
					{
						$s1despacho = "NADA HOUVE";
						$s1check = "";
					}
					if ($s2despacho == "")
					{
						$s2despacho = "NADA HOUVE";
						$s2check = "";
					}
					if ($s3despacho == "")
					{
						$s3despacho = "NADA HOUVE";
						$s3check = "";
					}
					if ($s4despacho == "")
					{
						$s4despacho = "NADA HOUVE";
						$s4check = "";
					}
					if ($bo1despacho == "")
					{
						$bo1despacho = "NADA HOUVE";
						$bo1check = "";
					}
					if ($bo2despacho == "")
					{
						$bo2despacho = "NADA HOUVE";
						$bo2check = "";
					}
					if ($bcdespacho == "")
					{
						$bcdespacho = "NADA HOUVE";
						$bccheck = "";
					}
					if ($aaedespacho == "")
					{
						$aaedespacho = "NADA HOUVE";
						$aaecheck = "";
					}
			}//fim if despachado
			
			//identificando o adjunto
			$resultadj = mysql_query("SELECT postograd, guerra FROM usuarios WHERE id='". $idusuario ."';",$conexaolivro);
			$postograd = mysql_result($resultadj,0,postograd);
			$guerra = mysql_result($resultadj,0,guerra);
			
			
			// Fun��o para transformar strings em Mai�scula ou Min�scula com acentos
			// $palavra = a string propriamente dita
			// $tp = tipo da convers�o: 1 para mai�sculas e 0 para min�sculas
			function convertem($term, $tp) {
				if ($tp == "1") $palavra = strtr(strtoupper($term),"������������������������������","������������������������������");
				elseif ($tp == "0") $palavra = strtr(strtolower($term),"������������������������������","������������������������������");
				return $palavra;
			} 
		
		echo'
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Livro Online</title>';
?>
<STYLE type=text/css>
H2 {page-break-before: always};
</STYLE>
<?
echo'
</head>

<body>
<table width="951" border="0">
  <tr>
    <td colspan="2"><div align="center"><img src="imagens/topo.png" width="380" height="233" /></div></td>
  </tr>
    <tr>
    <td colspan="2"><div align="center">
		<table border="1">
			<tr>
				<td><strong>
					<center> SERVI�O DO DIA&nbsp;';
					echo $diainicio;
					echo'/';
					echo $mesinicio;
					echo'/';
					echo $anoinicio;
					echo'&nbsp; PARA&nbsp;';
					echo $diatermino;
					echo'/';
					echo $mestermino;
					echo'/';
					echo $anotermino;
				echo '</strong></td>
			</tr>
		</table>
	
	</div></td>
  </tr>
  <tr>
  	<td colspan="2"></td>
  </tr><tr>
  	<td colspan="2"><strong><CENTER>PRIMEIRA PARTE: SERVI�OS DI�RIOS</strong></td>
  </tr>
  <tr>
  	<td colspan="2"></td>
  </tr>
  <tr>
    <td width="20"><strong>1.</strong></td>
    <td width="915"><strong>Parada Di&aacute;ria:</strong></td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
	
	//corrigindo o su
		switch ($parada){
		
			case 's1':
				$parada='a cargo do chefe da 1� se��o';
				break;
			case 'of':
				$parada='a cargo do oficial de dia';
				break;
				}
	
	
	echo convertem($parada, 1);
	
	echo'
	</td>
  </tr>
  <tr>
    <td><strong>1.1.</strong></td>
    <td><strong>Altera&ccedil;&otilde;es na Parada Di&aacute;ria:</strong></td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
	
	echo convertem($alterparada, 1);
	
	echo'
	</td>
  </tr>
  <tr>
    <td><strong>2.</strong></td>
    <td><strong>Recebimento do Servi&ccedil;o: </strong></td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;RECEBI-O COM TODAS AS ORDENS EM VIGOR DO&nbsp;';
	
	
	//corrigindo o posto
		switch ($recebipostograd){
		
			case '1ten':
				$recebipostograd='1� ten';
				break;
			case '2ten':
				$recebipostograd='2� ten';
				break;
				}  
				
	echo convertem($recebipostograd, 1);
	echo '&nbsp;';
	
	echo convertem($recebinome, 1);
	echo'
	</td>
  </tr>
  <tr>
    <td><strong>3.</strong></td>
    <td><strong>Pessoal de Servi&ccedil;o </strong></td>
  </tr>
  <tr>
    <td colspan="2">
	<table width="887" border="1" align="center">
      <tr>
        <td width="283"><div align="center"><strong>Fun&ccedil;&atilde;o</strong></div></td>
        <td width="291"><div align="center"><strong>Postograd</strong></div></td>
        <td width="291"><div align="center"><strong>Nome de Guerra </strong></div></td>
      </tr>
      ';
	  /////////////////////////////// imprimindo a tabela pessoal de sv
	  
	  		//trasnformando a string novamente em array
	  		$funcaosv = explode(",", $funcaosv);
			$postogradsv = explode(",", $postogradsv);
			$nomesv = explode(",", $nomesv);

	  		$Quantos= count($funcaosv) ;
			//para checar as vari�veis descomente a linha abaixo
			//echo $Quantos; echo ' Quantos'; print_r($funcaosv);
			if ($Quantos > 0){
			$i=0;
			for ($i==0; $i<$Quantos; $i++)
						{
							
							echo '<tr><td><center>';
							//corrigindo a fun��o
							switch ($funcaosv[$i]){
								case 'ofdia':
									$funcaosv[$i]='of dia';
									break;
								case 'adjofdia':
									$funcaosv[$i]='adj of dia';
									break;
								case 'cmtgda':
									$funcaosv[$i]='cmt gda';
									break;
								case 'cbgdafte':
									$funcaosv[$i]='cb gda fte';
									break;
								case 'cbgdafun':
									$funcaosv[$i]='cb gda fun';
									break;
								case 'motdia':
									$funcaosv[$i]='mot dia';
									break;	
								case 'sgtdran':
									$funcaosv[$i]='sgt d ran';
									break;
								case 'comsoc':
									$funcaosv[$i]='com soc';
									break;
								case 'medsbv':
									$funcaosv[$i]='med sbv';
									break;
								case 'dentsbv':
									$funcaosv[$i]='dent sbv';
									break;
								case 'atddia':
									$funcaosv[$i]='atd dia';
									break;
								case 'eltdia':
									$funcaosv[$i]='elt dia';
									break;
								case 'teldia':
									$funcaosv[$i]='tel dia';
									break;
								case 'permcanil':
									$funcaosv[$i]='perm canil';
									break;	
								case 'revdia':
									$funcaosv[$i]='rev dia';
									break;	
									} 
							echo convertem($funcaosv[$i], 1);
							echo '</td>';
							echo '<td><center>';
							//corrigindo o posto
							switch ($postogradsv[$i]){
								case 'cap':
									$postogradsv[$i]='cap';
									break;
								case '1ten':
									$postogradsv[$i]='1� ten';
									break;
								case '2ten':
									$postogradsv[$i]='2� ten';
									break;
								case '1sgt':
									$postogradsv[$i]='1� sgt';
									break;
								case '2sgt':
									$postogradsv[$i]='2� sgt';
									break;
								case '3sgt':
									$postogradsv[$i]='3� sgt';
									break;	
								case 'sdnb':
									$postogradsv[$i]='sd nb';
									break;
								case 'sdev':
									$postogradsv[$i]='sd ev';
									break;
									}  
							
							echo convertem($postogradsv[$i], 1);
							echo '</td>';
							echo '<td><center>';
							echo convertem($nomesv[$i], 1);
							echo '</td></tr>';
						}
			
						}
						else
						{
							echo'<td colspan="3"><center>Erro! Pessoal de SV n�o encontrado.</td>';
						}
	  //////////////////////////////////
        echo'
      
    </table>
	</td>
  </tr>
  <tr>
    <td><strong>4.</strong></td>
    <td><strong>Puni&ccedil;&otilde;es</strong></td>
  </tr>
  <tr>
    <td colspan="2">';
	  
	  /////////////////////////////// imprimindo a tabela puni��o
	  
	  		//trasnformando a string novamente em array
			if ($postogradpun != ""){
	  		$postogradpun = explode(",", $postogradpun);
			$numeropun = explode(",", $numeropun);
			$guerrapun = explode(",", $guerrapun);
			$supun = explode(",", $supun);
			$punicpun = explode(",", $punicpun);		
			$ndiaspun = explode(",", $ndiaspun);
			$inipun = explode(",", $inipun);
			$terpun = explode(",", $terpun);
			$bipun = explode(",", $bipun);
			
	  		$Quantos= count($postogradpun) ;
			//para checar as vari�veis descomente a linha abaixo
			//echo $Quantos; echo ' Quantos'; print_r($postogradpun);

			if ($Quantos > 0){
			
			echo'<table width="931" border="1" align="center">
				  <tr>
					<td width="86"><div align="center"><strong>Posto/Grad </strong></div></td>
					<td width="66"><div align="center"><strong>N&uacute;mero</strong></div></td>
					<td width="206"><div align="center"><strong>Nome</strong></div></td>
					<td width="81"><div align="center"><strong>SU</strong></div></td>
					<td width="89"><div align="center"><strong>Puni&ccedil;&atilde;o</strong></div></td>
					<td width="70"><div align="center"><strong>Dias</strong></div></td>
					<td width="98"><div align="center"><strong>In&iacute;cio</strong></div></td>
					<td width="98"><div align="center"><strong>T&eacute;rmino</strong></div></td>
					<td width="79"><div align="center"><strong>BI</strong></div></td>
				  </tr>';
			
			
			$i=0;
			for ($i==0; $i<$Quantos; $i++)
						{
							
							echo '<tr><td><center>';
							//corrigindo o posto
							switch ($postogradpun[$i]){
								case 'cap':
									$postogradpun[$i]='cap';
									break;
								case '1ten':
									$postogradpun[$i]='1� ten';
									break;
								case '2ten':
									$postogradpun[$i]='2� ten';
									break;
								case '1sgt':
									$postogradpun[$i]='1� sgt';
									break;
								case '2sgt':
									$postogradpun[$i]='2� sgt';
									break;
								case '3sgt':
									$postogradpun[$i]='3� sgt';
									break;	
								case 'sdnb':
									$postogradpun[$i]='sd nb';
									break;
								case 'sdev':
									$postogradpun[$i]='sd ev';
									break;
									}  

							echo convertem($postogradpun[$i], 1);
							echo '</td>';
							echo '<td><center>';
							echo convertem($numeropun[$i], 1);
							echo '</td>';
							echo '<td><center>';
							echo convertem($guerrapun[$i], 1);
							echo '</td>';
							echo '<td><center>';
							//corrigindo a su
							switch ($supun[$i]){
								case '1bo':
									$supun[$i]='1� BO';
									break;
								case '2bo':
									$supun[$i]='2� BO';
									break;
									} 
									
							echo convertem($supun[$i], 1);
							echo '</td>';
							echo '<td><center>';
							
							//convertendo puni��o
							switch($punicpun[$i])
							{
							case 'id': 
								$punicpun[$i] = 'imp. dis.';
							break;
							case 'det': 
								$punicpun[$i] = 'deten��o';
							break;
							case 'pr': 
								$punicpun[$i] = 'pris�o';
							break;			
							}
							echo convertem($punicpun[$i], 1);
							echo '</td>';
							echo '<td><center>';
							echo convertem($ndiaspun[$i], 1);
							echo '</td>';
							echo '<td><center>';
							echo convertem($inipun[$i], 1);
							echo '</td>';
							echo '<td><center>';
							echo convertem($terpun[$i], 1);
							echo '</td>';
							echo '<td><center>';
							echo convertem($bipun[$i], 1);
							echo '</td></tr>';

						}
						echo '</table>';
			
						}
						
			}
			else
			{
				echo'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;N�O HOUVE PUNI��O.';
			}
	  //////////////////////////////////
	  
	  echo'
    </td>
  </tr>
  <tr>
    <td><strong>5.</strong></td>
    <td><strong>Correspond&ecirc;ncia:</strong></td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
	echo convertem($correspondencia, 1);
	echo'
	</td>
  </tr>
  <tr>
    <td><strong>6.</strong></td>
    <td><strong>Apresenta&ccedil;&atilde;o:</strong></td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
	echo convertem($apresmil, 1);
	echo'
	</td>
  </tr>
  <tr>
    <td><strong>7.</strong></td>
    <td><strong>Ronda Interna:</strong></td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
	echo convertem($rondaint, 1);
	echo'
	</td>
  </tr>
  <tr>
    <td><strong>7.1.</strong></td>
    <td><strong>Ronda Externa: </strong></td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
	echo convertem($rondaext, 1);
	echo'
	</td>
  </tr>
  <tr>
    <td><strong>8.</strong></td>
    <td><strong>Revista do Recolher: </strong></td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
	 switch ($revistarec){
	 	case 'sa' :
			$revistarec = 'sem altera��o';
			break;
		case 'ca' :
			$revistarec = 'com altera��o';
			break;
			}

	echo convertem($revistarec, 1);
	echo'</td>
  </tr>
  <tr>
    <td><strong>8.1.</strong></td>
    <td><strong>Altera&ccedil;&atilde;o na Revista do Recolher: </strong></td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
	echo convertem($alterrevrec, 1);
	echo'</td>
  </tr>
  <tr>
    <td><strong>9.</strong></td>
    <td><strong>Ocorr&ecirc;ncias:</strong></td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
	echo convertem($ocorrencias, 1);
	echo'</td>
  </tr>
  <tr>
  	<td colspan="2"></td>
  </tr>
<tr>
  	<td colspan="2"><center><strong>SEGUNDA PARTE: ASSUNTOS ADMINISTRATIVOS</strong></td>
  </tr>
  <tr>
  	<td colspan="2"></td>
  </tr>
  <tr>
    <td><strong>1.</strong></td>
    <td><strong>Material Carga:</strong></td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
	echo convertem($famatcarga, 1);
	echo'</td>
  </tr>
    <tr>
    <td><strong>2.</strong></td>
    <td><strong>Depend�ncias:</strong></td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
	echo convertem($fadependencias, 1);
	echo'</td>
  </tr>
    <tr>
    <td><strong>3.</strong></td>
    <td><strong>Telefones e Alarmes:</strong></td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
	echo convertem($fatelalarmes, 1);
	echo'</td>
  </tr>
    <tr>
    <td><strong>4.</strong></td>
    <td><strong>Leitura de Energia:</strong></td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;CONSUMO: ';
	echo convertem($faenergiaconsumo, 1);
	echo'</td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;DEMANDA: ';
	echo convertem($faenergiademanda, 1);
	echo'</td>
  </tr>
  <tr>
    <td><strong>5.</strong></td>
    <td><strong>Clavicul�rio:</strong></td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
	echo convertem($faclaviculario, 1);
	echo'</td>
  </tr>
  <tr>
    <td><strong>6.</strong></td>
    <td><strong>Abastecimento:</strong></td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
	echo convertem($faabastecimento, 1);
	echo'</td>
  </tr>
  <tr>
    <td><strong>7.</strong></td>
    <td><strong>Viatura de Dia:</strong></td>
  </tr>
  <tr>
	  	<td colspan="2">
			<table width="931" border="1" align="center">
				<tr>
					<td>
						<center>Ton</center>
					</td>
					<td>
						<center>EB</center>
					</td>
					<td>
						<center>Od Sa�da</center>
					</td>
					<td>
						<center>Od Chegada</center>
					</td>
					<td>
						<center>Diferen�a</center>
					</td>
					<td>
						<center>Obs</center>
					</td>
				</tr>
				<tr>
					<td><center>
					   ';
						echo convertem($favtrton, 1);
						echo'
					</td>
					<td>
						<center>
					   ';
						echo convertem($favtreb, 1);
						echo'
					</td>
					<td>
						<center>
					   ';
						echo convertem($favtrodsaida, 1);
						echo'
					</td>
					<td>
						<center>
					   ';
						echo convertem($favtrodchegada, 1);
						echo'
					</td>
					<td>
						<center>
					   ';
						echo convertem($favtrdiferenca, 1);
						echo'
					</td>
					<td>
						<center>
					   ';
						echo convertem($favtrobs, 1);
						echo'
					</td>
				</tr>
			</table>
		
		<td>
	  </tr>
	  <tr>
		<td><strong>8.</strong></td>
		<td><strong>Po�o Artesiano:</strong></td>
	  </tr>
	  <tr>
		<td colspan="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
		echo convertem($fapocoartesiano, 1);
		echo'</td>
	  </tr>
	  <tr>
		<td><strong>9.</strong></td>
		<td><strong>Luzes de Emerg�ncia:</strong></td>
	  </tr>
	  <tr>
		<td colspan="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
		echo convertem($faluzemergencia, 1);
		echo'</td>
	  </tr>
	  <tr>
		<td><strong>10.</strong></td>
		<td><strong>Rancho:</strong></td>
	  </tr>
	  <tr>
		<td colspan="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SOBRAS: ';
		echo convertem($faransobras, 1);
		echo' Kg</td>
	  </tr>
	  <tr>
		<td colspan="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;RES�DUOS: ';
		echo convertem($faranresiduos, 1);
		echo' Kg</td>
	  </tr>
	  <tr>
		<td colspan="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ARRANCHAMENTO: ';
		echo convertem($faranarranchamento, 1);
		echo'</td>
	  </tr>
	  <tr>
		<td colspan="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;DEFESA ALIMENTAR: ';
		echo convertem($farangeneros, 1);
		echo'</td>
	  </tr>
	  <tr>
		<td><strong>11.</strong></td>
		<td><strong>Muni��o:</strong></td>
	  </tr>
	  <tr>
		<td colspan="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
		echo convertem($famunicao, 1);
		echo'</td>
	  </tr>
  
  
  
  
  
  
  <tr>
    <td><strong>12.</strong></td>
    <td><strong>Passagem do Servi&ccedil;o:</strong></td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;FIZ AO&nbsp;';
	
	//corrigindo o posto
		switch ($passeipostograd){
		
			case '1ten':
				$passeipostograd='1� ten';
				break;
			case '2ten':
				$passeipostograd='2� ten';
				break;
				}  
	
	//corrigindo o posto do of de dia que ser� usado log abaixo
		switch ($ofdiaposto){
		
			case '1ten':
				$ofdiaposto='1� ten';
				break;
			case '2ten':
				$ofdiaposto='2� ten';
				break;
				}  
				
	echo convertem($passeipostograd, 1);
	echo '&nbsp;';
	echo convertem($passeinome, 1);
	echo '&nbsp;COM TODAS AS ORDENS EM VIGOR';
	echo'</td>
  </tr>
  <tr>
	<td colspan="2"><br><center><strong>Adjunto ao Oficial de Dia&nbsp;: &nbsp;<label>';
	//corrigindo o posto
	switch ($postograd){
		case '1sgt':
			$postograd='1� SGT';
			break;
		case '2sgt':
			$postograd='2� SGT';
			break;
		case '3sgt':
			$postograd='3� SGT';
			break;	
			}  
	
	echo $postograd;
	echo '&nbsp;';
	echo convertem($guerra, 1);
	echo '
	</label></td>
  </tr>
  <tr>
    <td colspan="2"><div align="center">
      <p><strong>Itu - SP, '; echo $diatermino;echo'/';echo $mestermino; echo'/'; echo $anotermino;
	  
	  
	  echo '</strong></p>
      <p><strong>______________________________________________________________________</strong></p><p></p>
	  <p><strong>'; echo convertem($ofdianome,1); echo '&nbsp;-&nbsp;'; echo convertem($ofdiaposto, 1);   echo'</strong></>
      <p><strong>Of de Dia </strong></p>';
	  
	  if($despachado == "s"){
	  
	  echo'
      <br>
	  <br>
	  <H2><CENTER>DESPACHOS</CENTER></H2>
	  <br>
	  <div align="left">
	  <strong>FISCAL:</strong>&nbsp;';
	  echo convertem($fiscaldespacho,1);
	  echo'<br>
	  <strong>CI�NCIA:</strong>&nbsp;';
	  if ($fiscalcheck == "n")
		  {
		  	$fiscalcheck='PENDENTE';
		  }
	  if ($fiscalcheck == "s")
		  {
		  	$fiscalcheck='TOMADA';
		  }
	  echo $fiscalcheck;
	  echo '
	  <br><br>
	  <strong>S1:</strong>&nbsp;';
	  echo convertem($s1despacho,1);
	  echo'<br>
	  <strong>CI�NCIA:</strong>&nbsp;';
	  if ($s1check == "n")
		  {
		  	$s1check='PENDENTE';
		  }
	  if ($s1check == "s")
		  {
		  	$s1check='TOMADA';
		  }
	  echo $s1check;
	  echo '
	  <br><br>
	  <strong>S2:</strong>&nbsp;';
	  echo convertem($s2despacho,1);
	  echo'<br>
	  <strong>CI�NCIA:</strong>&nbsp;';
	  if ($s2check == "n")
		  {
		  	$s2check='PENDENTE';
		  }
	  if ($s2check == "s")
		  {
		  	$s2check='TOMADA';
		  }
	  echo $s2check;
	  echo'<br><br>
	  <strong>S3:</strong>&nbsp;';
	  echo convertem($s3despacho,1);
	  echo'<br>
	  <strong>CI�NCIA:</strong>&nbsp;';
	  if ($s3check == "n")
		  {
		  	$s3check='PENDENTE';
		  }
	  if ($s3check == "s")
		  {
		  	$s3check='TOMADA';
		  }
	  echo $s3check;
	  echo'<br><br>
	  <strong>S4:</strong>&nbsp;';
	  echo convertem($s4despacho,1);
	  echo'<br>
	  <strong>CI�NCIA:</strong>&nbsp;';
	  if ($s4check == "n")
		  {
		  	$s4check='PENDENTE';
		  }
	  if ($s4check == "s")
		  {
		  	$s4check='TOMADA';
		  }
	  echo $s4check;
	  echo'<br><br>
	  <strong>1� BO:</strong>&nbsp;';
	  echo convertem($bo1despacho,1);
	  echo'<br>
	  <strong>CI�NCIA:</strong>&nbsp;';
	  if ($bo1check == "n")
		  {
		  	$bo1check='PENDENTE';
		  }
	  if ($bo1check == "s")
		  {
		  	$bo1check='TOMADA';
		  }
	  echo $bo1check;
	  echo'<br><br>
	  <strong>2� BO:</strong>&nbsp;';
	  echo convertem($bo2despacho,1);
	  echo'<br>
	  <strong>CI�NCIA:</strong>&nbsp;';
	  if ($bo2check == "n")
		  {
		  	$bo2check='PENDENTE';
		  }
	  if ($bo2check == "s")
		  {
		  	$bo2check='TOMADA';
		  }
	  echo $bo2check;
	  echo'<br><br>
	  <strong>BC:</strong>&nbsp;';
	  echo convertem($bcdespacho,1);
	  echo'<br>
	  <strong>CI�NCIA:</strong>&nbsp;';
	  if ($bccheck == "n")
		  {
		  	$bccheck='PENDENTE';
		  }
	  if ($bccheck == "s")
		  {
		  	$bccheck='TOMADA';
		  }
	  echo $bccheck;
	  echo'<br><br>
	  <strong>AAE L:</strong>&nbsp;';
	  echo convertem($aaedespacho,1);
	  echo'<br>
	  <strong>CI�NCIA:</strong>&nbsp;';
	  if ($aaecheck == "n")
		  {
		  	$aaecheck='PENDENTE';
		  }
	  if ($aaecheck == "s")
		  {
		  	$aaecheck='TOMADA';
		  }
	  echo $aaecheck;
	  echo'<br><br>
	  <p><strong><center>__________________________________________________</strong></p><p></p>
	  <p><strong><center>RODRIGO CUNHA DA SILVA - MAJ</strong></p><p></p>
      <p><strong><center>Scmt 2� GAC L</strong></p><p></p>

	   

	  </div>
	  
	  ';
	}//fim if despachado
	else
	{}
	echo'
	</div></td>
  </tr>
</table>
</body>
</html>';
	}
	else //caso a consulta ao BD n�o retorne nenhum livro
	{
	  echo"<center> Erro!<br> Nenhum livro encontrado com este c�digo<br>Contate o Administrador.";
	}
}
else
	{
	echo '<center>Usuario n�o autorizado!';
	}
}
else
	{
	echo '<center>Usuario n�o autorizado!';
	}
	?>
