<?
session_start();
include "base.php";
if (isset($_SESSION['nivel'])) 
{
 	$logado = $_SESSION['nivel'];
	$idusuario = $_SESSION['id'];
  	if ($logado)
	{		
		echo'<html>
		<head>
		<title>Alterar Dados</title>
		</head>
		<body>';
		//recebendo vari�vel
		//retirando as oespa�os e aspas		
		$postograd= str_replace(" ", "%", $HTTP_POST_VARS[postograd]);
		$nome= $HTTP_POST_VARS[nome];
		$guerra= $HTTP_POST_VARS[guerra];
		$idt= $HTTP_POST_VARS[idt];
		$su= str_replace(" ", "%", $HTTP_POST_VARS[su]);
		
		//inserindo no banco		
		$result = mysql_query("UPDATE usuarios SET postograd='". $postograd ."', nome='". $nome ."',guerra='". $guerra ."',idt='". $idt ."',su='". $su ."' WHERE id='".$idusuario."';",$conexaolivro);
       
		if ($result)
			{
			echo '<center>Cadastro Alterado com Sucesso!';
			}
		else
			{
				echo '<center> Erro ao alterar as cadastro! contate o administrador!';
			}
	
		}
			else
				{
					echo '<center>Usuario n�o autorizado!';
				}
		}
else
{
	echo '<center>Usuario n�o autorizado!';
}
?>

</body>
</body>
</html>
